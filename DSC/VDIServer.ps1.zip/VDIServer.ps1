#
# VDA.ps1
#
configuration VDIServer
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$DeliveryController,

        [Parameter(Mandatory)]
        [String]$DomainControllerIp,
        

        [Parameter(Mandatory)]
        [String]$setupLocation,
		
        [Parameter(Mandatory)]
        [String]$CreateMasterImage		
    ) 

    Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
    
    Import-DscResource -ModuleName CitrixXenDesktopAutomation, CitrixMarketplace, cChoco, xNetworking,  xActiveDirectory, xComputerManagement

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    
	$Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

	
    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
        } 

		WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 
		
		Registry ListOfDDC
        {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\Software\Citrix\VirtualDesktopAgent"
            ValueName = "ListOfDDCs"
            ValueData = $DeliveryController
            DependsOn = "[WindowsFeature]ADPowershell" 
        }
		
	    xDnsServerAddress DnsServerAddress
        {
            Address        = $DomainControllerIp
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }

		
		 xWaitForADDomain WaitForDomain 
		{ 
			DomainName = $DomainName 
			DomainUserCredential= $Admincreds
			RetryCount = $RetryCount 
			RetryIntervalSec = $RetryIntervalSec
			DependsOn = "[xDnsServerAddress]DnsServerAddress" 
		}

		xComputer DomainJoin
		{
			Name = $env:COMPUTERNAME
			DomainName = $DomainName
			Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]WaitForDomain" 
		}
				
				
		$currentVdiInstallerDir = (join-path -Path "c:\" -ChildPath "VDISetup")
		$CurrentVdiInstallerPath = (join-path -Path $currentVdiInstallerDir -ChildPath "VDI.exe")
		
		Script InstallVDI
        {            
          
            GetScript = { @{} }      
                     
            TestScript = {            
                return (Test-Path $using:currentVdiInstallerDir) -eq $true

            }            
            
            SetScript = {     
                New-Item $using:currentVdiInstallerDir  -type directory
				Invoke-WebRequest -Uri $using:setupLocation -OutFile $using:CurrentVdiInstallerPath
				$arguments = "/enable_real_time_transport /enable_hdx_ports /components vda,plugins /QUIET  /controllers $DeliveryController"
				
				if([System.Convert]::ToBoolean($CreateMasterImage) -eq $true)
				{
					$arguments = $arguments + " /masterimage"
				}
					
                Start-Process $using:CurrentVdiInstallerPath -ArgumentList $arguments -Wait
				Restart-Computer               
            }            
            DependsOn ="[xComputer]DomainJoin"
        }
        
        
    }
} 
