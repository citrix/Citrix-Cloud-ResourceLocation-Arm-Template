function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$LocalPath,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)

    process
    {
	    return @{
		    Filename = $Filename
            NetscalerIP = $NetscalerIP
		    Base64Data = $Base64Data
            LocalPath = $LocalPath
            Reboot = $Reboot
            UseHttps = $UseHttps
            Ensure = $Ensure
	    }
    }
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$LocalPath,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)

    begin
    {    
	    if((-not $LocalPath) -or (-not (Test-Path $LocalPath)))
	    {
		    throw "Invalid local file system path specified"
	    }
	}

    process
    {
	    if($UseHttps)
	    {
		    Set-Protocol "HTTPS"
	    }
	    else
	    {
		    Set-Protocol "HTTP"
	    }
	
        if($Ensure -eq "Present")
        {
            # Directly local copy file to NetScaler over scp

		    $username = $NetscalerCredential.UserName
		    $password  = $NetscalerCredential.GetNetworkCredential().password

		    Invoke-NetscalerPSCP -Hostname $NetscalerIP -Credentials $NetscalerCredential `
                                 -Local $LocalPath -Target $Filename
        }
        else 
        {
            Invoke-NetscalerSSH -Hostname $NetscalerIP -Credentials $NetscalerCredential `
                                -Commands "rm $Filename"
        }

        if($Reboot)
        {
            # If restarting, expect underlying connection to close

            try {
                Restart-NetScalerVpx -NSIP $NetscalerIP -SaveNSConfig -WebSession $session | Out-Null
            } catch { }
        }
    }
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$LocalPath,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)

	begin
    {    
	    if((-not $LocalPath) -or (-not (Test-Path $LocalPath)))
	    {
		    throw "Invalid local file system path specified"
	    }
	}

    process
    {
        # Check target file to see if it matches the intended

	    $username = $NetscalerCredential.UserName
	    $password = $NetscalerCredential.GetNetworkCredential().password
	
	    $path = (Split-Path -Path $Filename).Replace("\", "/")
	    $name = Split-Path -Path $Filename -Leaf
	
        $output = Invoke-NetscalerSSH -Hostname $NetscalerIP -Credentials $NetscalerCredential -Commands "ls $path"
	
        if($Ensure -eq "Present")
        {
    	    $present = (-not (($output | ?{$_ -match $name }) -eq $null))
		
		    if($present) 
		    {
			    $wc = Invoke-NetscalerSSH -Hostname $NetscalerIP -Credentials $NetscalerCredential -Commands "wc -c $path"
			
			    if($wc -match '([0-9]+)') 
			    {
				    $bytes = [int]$matches[0]
				    $localBytes = (get-item $LocalPath | get-content -Encoding Byte | measure-object).Count
				
				    if($bytes -ne $localBytes)
				    {
					    return $false
				    }
			    }
		    }
		
		    return $present
        }
        else 
        {
    	    return ((($output | ?{$_ -match $name }) -eq $null))
        }
    }
}

. "$PSScriptRoot\..\NetScalerConfiguration.ps1"

Export-ModuleMember -Function *-TargetResource

