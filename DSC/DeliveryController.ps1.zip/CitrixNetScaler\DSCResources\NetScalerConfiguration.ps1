
<# 
.SYNOPSIS
    This module file contains single-sourced NetScaler Configuration functions.

    Copyright (c) Citrix Systems, Inc. All Rights Reserved.
.DESCRIPTION
    This module file contains single-sourced NetScaler Configuration functions.
#> 
Set-StrictMode -Version Latest

# Define default URL protocol to https, which can be changed by calling Set-Protocol function
$Script:URLProtocol = "https"

function Send-NetscalerSystemFile{
    <#
    .SYNOPSIS
        Sends a file to Netscaler device using NITRO REST API
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Send file
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter Filename
        Name of file for given data
    .Parameter Location
        Location of file on Netscaler device
    .Parameter Base64Data
        Base 64 representation of binary data to be sent as the file
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function 
    .EXAMPLE
        Send-SystemFile -Base64Data -Filename /nsconfig/ssl/cert.key
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $Filename,
    [Parameter(Mandatory=$true)][string] $Location,
    [Parameter(Mandatory=$true)][string] $Base64Data,
    [Parameter(Mandatory=$true)] $WebSession
    )

    $payload = @{filename=$Filename;filecontent=$Base64Data;filelocation=$Location;fileencoding="BASE64"}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType systemfile -WebSession $WebSession -Payload $payload -Action add 
}

function Initialize-NetScalerVPXOnXenServer{    
    <#
    .SYNOPSIS
        Initialize the NetScaler VPX pn XenServer by setting the NSIP, NetMask and GatewayIP

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Initialize the NetScaler VPX on XenServer by setting the NSIP, NetMask and GatewayIP
        This method is documented as support article http://support.citrix.com/article/CTX128236
        Once this is done, the netscaler VPX becomes reachable through ssh
    .Parameter HypervisorIP
        Hypervisor IPAddress
    .Parameter HypervisorUserName
        UserName to access the hypervisor 
    .Parameter HypervisorPassword
        Password to access the hypervisor 
    .Parameter NsVpxVmUuid
        XenServer UUID of the NetScaler VPX VM
    .Parameter NSIP
        IPAddress of the NetScaler VPX
    .Parameter NetMask
        Subnet Mask of the NetScaler VPX IpAddress
    .Parameter GatewayIP
        Default Gateway IPAddress
    .EXAMPLE
        Initialize the NetScaler VPX by setting the NSIP, NetMask and GatewayIP
        Initialize-NetScalerVPXOnXenServer -HypervisorIP 10.8.115.155 -HypervisorUserName pooladmin171x03 -HypervisorPassword abcdefg `
        -NsVpxVmUuid 7811767d-e2fd-872c-71d9-e208f27728a8 -NSIP 10.108.151.1 -Netmask 255.255.248.0 -GatewayIP 10.108.141.1 |Out-Null

    #>
	[CmdletBinding()]
    param(
		[Parameter(Mandatory=$true)] [string] $HypervisorIP,
    	[Parameter(Mandatory=$true)] [string] $HypervisorUserName,
    	[Parameter(Mandatory=$true)] [string] $HypervisorPassword,
    	[Parameter(Mandatory=$true)] [string] $NsVpxVmUuid,
    	[Parameter(Mandatory=$true)] [string] $NSIP, 
    	[Parameter(Mandatory=$true)] [string] $NetMask, 
    	[Parameter(Mandatory=$true)] [string] $GatewayIP)

    #Load-XenserverSnapin
	Write-Verbose "Invoking function Initialize-NetScalerVPXOnXenServer"

	add-pssnapin XenServerPSSnapIn -ErrorAction SilentlyContinue
   	$password = convertTo-SecureString $HypervisorPassword -AsPlainText -Force 
	$creds = new-object System.Management.Automation.Pscredential($HypervisorUserName, $password)
	connect-xenserver -server $HypervisorIP -creds $creds -NoWarnNewCertificates -NoWarnCertificates -Port 80   |out-null

    add-XenServer:VM.XenStoreData -VM $NsVpxVmUuid -key vm-data/ip -Value $NSIP  -Server $HypervisorIP -Port 80
    add-XenServer:VM.XenStoreData -VM $NsVpxVmUuid -key vm-data/netmask -Value $NetMask -Server $HypervisorIP -Port 80
    add-XenServer:VM.XenStoreData -VM $NsVpxVmUuid -key vm-data/gateway -Value $GatewayIP -Server $HypervisorIP -Port 80
    
	Disconnect-Xenserver -server $HypervisorIP -Port 80|out-null
}

function Send-NetScalerLicenses{    
    <#
    .SYNOPSIS
        Uploading the license file(s) to NetScaler VPX

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Uploading the license file(s) to license folder of NetScaler VPX. Destination file names are the same as source file names
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter NSUserName
        UserName to access the NetScaler Managerment Console, default to nsroot
    .Parameter NSPassword
        Password to access the NetScaler Managerment Console, default to nsroot
    .Parameter PathsToLicenseFile
        Full path to the source of the licenseFile, allow value from Pipeline
    .EXAMPLE
        Send two license files to NetScaler VPX with IPAddress 10.108.151.1
        $licfiles = @("C:\NSLicense\CAG_Enterprise_VPX_2012.lic","C:\NSLicense\CAGU-Hostname_10000CCU_sslvpn-sg.lic")
		$res = $licfiles|Send-NetScalerLicenses -NSIP 10.108.151.1

    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP, 
    [Parameter(Mandatory=$false)][string] $NSUserName="nsroot", 
    [Parameter(Mandatory=$false)][string] $NSPassword="nsroot",
    [Parameter(Mandatory=$true,  ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)] [string] $PathsToLicenseFile
   )
    BEGIN {
        Write-Verbose "Invoking function Send-NetScalerLicenses"
    }
    PROCESS {
        Write-Verbose "Upload license file $PathsToLicenseFile to NetScaler VPX $NSIP"
        $licenseFileName = Split-Path -Path $PathsToLicenseFile -Leaf
        $res = invoke-pscp -Source $PathsToLicenseFile  -Password $NSPassword -User $NSUserName -Target "$($NSIP):/nsconfig/license/$licenseFileName" -Recursive -PreserveFileAttributes
    } 
    END {
        Write-Verbose "Finished uploading all license files to NetScaler VPX $NSIP"
    }   
}
function Restart-NetScalerVpx{
    <#
    .SYNOPSIS
        Restart NetScaler VPX, with an option to save NetScaler Config File before rebooting

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Restart NetScaler VPX, with an option to save NetScaler Config File before rebooting
    .Parameter NSIP
        NetScaler Management IPAddress
	.Parameter SaveNSConfig
        Switch Parameter to save NetScaler Config file before rebooting.
    .Parameter WarmReboot
        Switch Parameter to perform warn reboot of the VPX
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function 
    .EXAMPLE
		Save NetScaler Config file and restart NetScaler VPX
        Restart-NetScalerVpx -NSIP 10.108.151.1 -SaveNSConfig -WebSession $session
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string] $NSIP,
	    [Parameter(Mandatory=$false)][switch] $SaveNSConfig,
	    [Parameter(Mandatory=$false)][switch] $WarmReboot,
        [Parameter(Mandatory=$true)] $WebSession

    )
	Write-Verbose "Invoking function Restart-NetScalerVpx"
	
	if($SaveNSConfig) {
    	Save-NSConfig -NSIP $NSIP -WebSession $WebSession
	}

    $payload = @{warm=$WarmReboot.ToBool()}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType reboot -WebSession $WebSession -Payload $payload -Action Reboot


}

function Save-NSConfig{
    <#
    .SYNOPSIS
        Save NetScaler Config File 

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Save NetScaler Config File 
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Save-NSConfig -NSIP 10.108.151.1 -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP, 
    [Parameter(Mandatory=$true)] $WebSession

    )
    #$session = Connect-NSVPX -NSIP $NSIP -NSUserName $NSUserName -NSPassword $NSPassword 
    

    $saveConfigJob = Invoke-NitroAPI -NSIP $NSIP -OperationMethod Post -Action "save" -ResourceType nsconfig -WebSession $WebSession


    #Disconnect-NSVPX -NSIP $NSIP

}

function Connect-NSVPX{
    <#
    .SYNOPSIS
        Connect to NetScaler VPX

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Connect to NetScaler VPX, a web request session object will be returned
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter NSUserName
        UserName to access the NetScaler Managerment Console,default to nsroot
    .Parameter NSPassword
        Password to access the NetScaler Managerment Console,default to nsroot
    .EXAMPLE
         $Session = Connect-NSVPX -NSIP 10.108.151.1
    .OUTPUTS
        Web Request Session object
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP, 
    [Parameter(Mandatory=$false)][string] $NSUserName="nsroot", 
    [Parameter(Mandatory=$false)][string] $NSPassword="nsroot"
    )
    $login =   @{"login" = @{"username"=$NSUserName;"password"=$NSPassword}}
    $loginJson = ConvertTo-Json $login -Depth 6

    $retries = 0
    $maxRetries = 10

    while($retries -lt $maxRetries)
    {
        try
        {
            $job = Invoke-RestMethod -Uri "http://$NSIP/nitro/v1/config/login" -Body $loginJson `
                                     -method POST -SessionVariable saveSession -ContentType application/json
   
            return  $saveSession
        }
        catch
        {
            $retries = $retries + 1
        }
    }

    throw "Could not connect. Exhausted retries"
}

function Disconnect-NSVPX{
    <#
    .SYNOPSIS
        Disconnect NetScaler VPX session

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Disconnect NetScaler VPX session
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter NSUserName
        UserName to access the NetScaler Managerment Console,default to nsroot
    .Parameter NSPassword
        Password to access the NetScaler Managerment Console,default to nsroot
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Disconnect-NSVPX -NSIP 10.108.151.1 -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)] $WebSession
    )

    $logoutJob = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType logout  -WebSession $WebSession


}
function Enable-NSVPXFeature {
    <#
    .SYNOPSIS
        Enable NetScaler VPX feature(s)

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Enable one or more NetScaler VPX feature(s)
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter Features
        Feature to be enabled. Multiple features can be specified by providing a blank space between each feature.
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Enable-NSVPXFeature -NSIP 10.108.151.1 -Features "sslvpn" -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $Features,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{feature=$Features}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType nsfeature -WebSession $WebSession -Payload $payload -Action enable

}

function Enable-NSVPXMode {
    <#
    .SYNOPSIS
        Enable NetScaler VPX Mode(s)

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Enable one or more NetScaler VPX Mode(s)
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter Modes
        Mode to be enabled. Multiple modes can be specified by providing a blank space between each mode.
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Enable-NSVPXModes -NSIP 10.108.151.1 -Modes "mbf" -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $Modes,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{mode=$Modes}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType nsmode -WebSession $WebSession -Payload $payload -Action enable

}

function Set-Timezone {
    <#
    .SYNOPSIS
        Set NetScaler VPX Timezone
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Set NetScaler VPX Timezone
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter TimeZone
        Name of the timezone. e.g. "GMT-05:00-EST-America/Panama"
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
         Set-Timezone -NSIP 10.108.151.1 -TimeZone "GMT-05:00-EST-America/Panama" -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $TimeZone,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{timezone=$TimeZone}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod put -ResourceType nsconfig -WebSession $WebSession -Payload $payload -Action update 

}

function Set-HostName {
    <#
    .SYNOPSIS
        Set NetScaler VPX Hostname
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Set NetScaler VPX Hostname
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter HostName
        Host name for the NetScaler appliance.
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
         Set-HostName -NSIP 10.108.151.1 -HostName "sslvpn-sg" -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $HostName,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{hostname=$HostName}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod PUT -ResourceType nshostname  -Payload $payload -Action update -WebSession $WebSession 

}

function Add-IP {
    <#
    .SYNOPSIS
        Create NetScaler VPX IP resource(s)
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Create NetScaler VPX IP resource(s)
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter IPAddress
        IPv4 address to create on the NetScaler appliance. Cannot be changed after the IP address is created.
    .Parameter Netmask
        Subnet mask associated with the IP address.
    .Parameter Type
        Type of the IP address to create on the NetScaler appliance. Cannot be changed after the IP address is created.
        Allowed values are "SNIP", "VIP", "MIP", "NSIP", "GSLBsiteIP", "CLIP", default to SNIP"
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add Subnet IP
        Add-IP -NSIP 10.108.151.1 -IPAddress 10.108.151.2 -Netmask 255.255.248.0 -WebSession $session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)][string] $IPAddress,
    [Parameter(Mandatory=$true)][string] $Netmask,
    [Parameter(Mandatory=$false)][string][ValidateSet("SNIP", "VIP", "MIP", "NSIP", "GSLBsiteIP", "CLIP")] $Type="SNIP",
    [Parameter(Mandatory=$true)] $WebSession
    )
    BEGIN {
        Write-Verbose "Invoking function Add-IP"
    }
    PROCESS {
        $payload = @{ipaddress=$IPAddress;netmask=$Netmask;type=$Type}
        $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType nsip -WebSession $WebSession -Payload $payload -Action add    
    }
    End {
        Write-Verbose "Leaving function Add-IP"
    }
}

function Add-CertKeyPair {
    <#
    .SYNOPSIS
        Add SSL certificate and private key pair
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add SSL certificate and private key  pair
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter CertKeyName
        Name for the certificate and private-key pair. 
    .Parameter CertPath
        Path to the X509 certificate file that is used to form the certificate-key pair. 
    .Parameter KeyPath
        path to the private-key file that is used to form the certificate-key pair. 
    .Parameter CertKeyFormat
        Input format of the certificate and the private-key files. , allowed values are "PEM" and "DER", default to "PEM"
    .Parameter Passcrypt
        Pass phrase used to encrypt the private-key. Required when adding an encrypted private-key in PEM format.
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-CertKeyPair -NSIP 10.108.151.1 -CertKeyName "*.xd.local" -CertPath "/nsconfig/ssl/ns.cert" -KeyPath "/nsconfig/ssl/ns.key" -CertKeyFormat PEM -Passcrypt "luVJAUxtmUY=" -WebSession $session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $CertKeyName,
    [Parameter(Mandatory=$true)][string] $CertPath,
    [Parameter(Mandatory=$true)][string] $KeyPath,
    [Parameter(Mandatory=$false)][string] [ValidateSet("PEM", "DER")] $CertKeyFormat="PEM",
    [Parameter(Mandatory=$false)][string] $Password,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{certkey=$CertKeyName;cert=$CertPath;key=$KeyPath;passplain=$Password;inform=$CertKeyFormat;bundle="YES"}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType sslcertkey -WebSession $WebSession -Payload $payload -Action add 

}

function Add-RootCert {
    <#
    .SYNOPSIS
        Add/Install SSL root certificate
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add SSL root certificate
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter CertName
        Name for the certificate and private-key pair. 
    .Parameter CertPath
        Path to the X509 certificate file that is used to form the certificate-key pair.  
    .Parameter CertFormat
        Input format of the certificate and the private-key files. , allowed values are "PEM" and "DER", default to "PEM"
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-RootCert -NSIP 10.108.151.1 -CertName "*.xd.local" -CertPath "/nsconfig/ssl/ns.cert" -CertKeyFormat PEM -WebSession $session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $CertName,
    [Parameter(Mandatory=$true)][string] $CertPath,
    [Parameter(Mandatory=$false)][string] [ValidateSet("PEM", "DER")] $CertKeyFormat="PEM",
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{certkey=$CertName;cert=$CertPath;inform=$CertKeyFormat}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType sslcertkey -WebSession $WebSession -Payload $payload -Action add 

}

function Add-ResponderAction {
<#
    .SYNOPSIS
        Add a responder action 
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add a responder action
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter Name
	    Name of the Responder Action
    .Parameter Type
        Type of the Responder Action  
    .Parameter Target
        Target Responder action to be added
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-ResponderAction -NSIP 10.108.151.1 -Name action404Error -Type respondWith -Target '"HTTP/1.1 404 Not Found\r\n\r\n"+ "HTTP.REQ.URL.HTTP_URL_SAFE" + "does not exist on the web server."' -WebSession $WebSession
    #>
	[CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $Name,
    [Parameter(Mandatory=$true)][string] $Type,
    [Parameter(Mandatory=$true)][string] $Target,
	[Parameter(Mandatory=$false)][switch] $BypassSafetyCheck=$false,
    [Parameter(Mandatory=$true)] $WebSession
    )
	$payload = @{name=$Name;type=$Type;target=$Target;bypassSafetyCheck=$BypassSafetyCheck}
	$Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType responderaction -WebSession $WebSession -Payload $payload -Action add -Verbose
}

function Add-ResponderPolicy {
<#
    .SYNOPSIS
        Add a responder policy 
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add a responder Policy
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter Name
	    Name of the Responder policy
    .Parameter ActionName
        Type the name of the action for this policy 
    .Parameter UndefinedAction
        Type the undefined action
	.Parameter Expression
		Type the rule/expression to be used
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-ResponderPolicy -NSIP 10.108.151.1 -Name policythree -Expression "CLIENT.IP.SRC.IN_SUBNET(222.222.0.0/16)" -ActionName delete_req_action -UndefinedAction DROP -WebSession $WebSession
    #>
	[CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $Name,
    [Parameter(Mandatory=$true)][string] $ActionName,
    [Parameter(Mandatory=$false)][string] $UndefinedAction,
	[Parameter(Mandatory=$true)][string] $Expression, 
    [Parameter(Mandatory=$true)] $WebSession
    )
	$payload = @{name=$Name;rule=$Expression;action=$ActionName;undefaction=$UndefinedAction}
	$Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType responderpolicy -WebSession $WebSession -Payload $payload -Action add
}

function Add-Monitor {
<#
    .SYNOPSIS
        Add a monitor(Incomplete) 
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add a monitor - Incomplete implementation. 
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter monitorName
		Name of the monitor	
	.Parameter type
		The type of monitor. Possible values: PING, TCP, HTTP, TCP-ECV, HTTP-ECV, UDP-ECV, DNS, FTP, LDNS-PING, LDNS-TCP, LDNS-DNS, RADIUS, USER, HTTP-INLINE, SIP-UDP, LOAD, FTP-EXTENDED, SMTP, SNMP, NNTP, MYSQL, MYSQL-ECV, MSSQL-ECV, LDAP, POP3, CITRIX-XML-SERVICE, CITRIX-WEB-INTERFACE, DNS-TCP, RTSP, ARP, CITRIX-AG, CITRIX-AAC-LOGINPAGE, CITRIX-AAC-LAS, CITRIX-XD-DDC, ND6, CITRIX-WI-EXTENDED, DIAMETER
	.Parameter action
		The action to be taken in INLINE monitors. Possible values: NONE, LOG, DOWN Default value: SM_DOWN
	.Parameter respCode
		The response codes. For the probe to succeed, the HTTP/RADIUS response from the server must be of one of the types specified.
	.Parameter httpRequest
		The HTTP request that is sent to the server (for example, "HEAD /file.html").
	.Parameter rtspRequest
		The RTSP request that is sent to the server (for example, "OPTIONS *").
	.Parameter customHeaders
		The custom header string, attached to the monitoring probes.
	.Parameter maxForwards
		SIP packet max-forwards Default value: 1 Maximum value: 255
	.Parameter sipMethod
		SIP method to be used for the query Possible values: OPTIONS, INVITE, REGISTER
	.Parameter sipURI
		SIP method string, sent to the server. For example "OPTIONS sip:sip.test".
	.Parameter sipregURI
		SIP user to be registered
	.Paramter send
		The string that is sent to the service. Applicable to TCP-ECV, HTTP-ECV, and UDP-ECV monitor types.
	.Parameter recv
		The string that is expected from the server to mark the server as UP. Applicable to TCP-ECV, HTTP-ECV, and UDP-ECV monitor types.
	.Parameter query
		The DNS query (domain name) sent to the DNS service that is being monitored.
	.Parameter queryType
		The type of DNS query that is sent. Possible values: Address, Zone, AAAA
	.Paramter scriptName
		The path and name of the script to execute.
	.Parameter scriptArgs
		The string that are put in the POST data - they are copied to the request verbatim.
	.Parameter dispatcherIP
		The IP Address of the dispatcher to which the probe is sent.
	.Parameter dispatcherPort
		The port of the dispatcher to which the probe is sent.
	.Parameter userName
		Username on the RADIUS/NNTP/FTP/FTP-EXTENDED/MYSQL/MSSQL/POP3/CITRIX-AG/CITRIX-XD-DDC/CITRIX-WI-EXTENDED server. This user name is used in the probe.
	.Parameter password
		Password used in RADIUS/NNTP/FTP/FTP-EXTENDED/MYSQL/POP3/LDAP/CITRIX-AG/CITRIX-XD-DDC/CITRIX-WI-EXTENDED server monitoring.
	.Parameter secondaryPassword
		Secondary password used in Access Gateway server monitoring.
	.Parameter logonpointName
		Logonpoint name used in Citrix AAC login page and logon agent service monitoring.
	.Parameter lasVersion
		The version of the Citrix AAC logon agent service required by CITRIX-AAC-LAS monitor.
	.Parameter radKey
		The radius key.
	.Parameter radNASid
		The NAS ID to be used in Radius monitoring.
	.Parameter radNASip
		The NAS IP to be used in Radius monitoring.
	.Parameter LRTM
		The state of response time calculation of probes. Possible values: ENABLED, DISABLED
	.Parameter deviation
		Deviation from the learnt response time for Dynamic Response Time monitoring. The maximum value is 20939000 in milliseconds , 20939 in seconds and 348 in minutes. Maximum value: 20939000
	.Parameter interval
		The frequency at which the probe is sent to a service.The interval should be greater than the response timeout. The minimum value is 20 msec.The maximum value is 20940000 in milliseconds , 20940 in seconds and 349 in minutes Default value: 5 Minimum value: 1 Maximum value: 20940000
	.Parameter resptimeout
		The interval for which the system waits before it marks the probe as FAILED. The response timeout should be less than the value specified in -interval parameter. The UDP-ECV monitor type does not decide the probe failure by the response timeout. System considers the probe successful for UDP-ECV monitor type, when the server response matches the criteria set by the -send and -recv options or if the response is not received from the server (unless the -reverse option is set to yes). Note:	The -send option specifies what data is to be sent to the server in the probe and -recv specifies the server response criteria for the probe to succeed. The probe failure is caused by the ICMP port unreachable error from the service. The minimum value is 10 msec. The maximum value is 20939000 in milliseconds , 20939 in seconds and 348 in minutes Default value: 2 Minimum value: 1 Maximum value: 20939000
	.Parameter resptimeoutThresh
		Monitor response timeout threshold , a trap will be sent if the response time for the monitoring probes exceeds the thereshold. It is given in percentage. Maximum value: 100
	.Parameter retries
		The maximum number of most recent probes considered to decide whether to mark the service as DOWN. Minimum value of retries is 1. Default value: 3 Minimum value: 1 Maximum value: 127
	.Parameter failureRetries
		The number of failed probes out of most recent "retries" number of probes required to mark the service as DOWN. By default, the system requires "retries" number of consecutive probe failures to mark the service as DOWN. Maximum value: 32
	.Parameter alertRetries
		The number of probes failures after which the system generates a snmp trap. Maximum value: 32
	.Parameter successRetries
		The number of consecutive sucessful probes required to mark the service as UP. Default value: 1 Minimum value: 1 Maximum value: 32
	.Parameter downTime
		The duration for which the system waits to make the next probe once the service is marked as DOWN. The minimum value is 10 msec. The maximum value is 20939000 in milliseconds , 20939 in seconds and 348 in minutes Default value: 30 Minimum value: 1 Maximum value: 20939000
	.Parameter destIP
		The IP address to which the probe is sent. If the destination IP address is set to 0, the destination IP address is that of the server to which the monitor is bound.
	.Parameter destPort
		The TCP/UDP port to which the probe is sent. If the destination port is set to 0, the destination port is of the service to which the monitor is bound. For a USER monitor, however, this will be the port sent in the HTTP request to the dispatcher. This option is ignored if the monitor is of the PING type.
	.Parameter state
		The state of the monitor. If the monitor is disabled, this monitor-type probe is not sent for all services. If the monitor is bound, the state of this monitor is not taken into account when the service of this state is determined. Possible values: ENABLED, DISABLED Default value: ENABLED
	.Parameter reverse
		The state of reverse probe's criterion check. Possible values: YES, NO Default value: NO
	.Parameter transparent
		The state of the monitor for transparent devices, such as firewalls, based on the responsiveness of the services behind them. If the monitoring of transparent devices is enabled, the destination IP address should be specified. The probe is sent to the specified destination IP address using the MAC address of the transparent device. Possible values: YES, NO Default value: NO
	.Parameter ipTunnel
		The state of the monitor for tunneled devices. If the monitoring of tunneled devices is enabled, the destination IP address should be specified. The probe is sent to the specified destination IP address by tunneling it to the device. Possible values: YES, NO Default value: NO
	.Parameter tos
		If enabled, the probe is sent to the service by encoding the specified destination IP address in the IP TOS (6)bits. Possible values: YES, NO
	.Parameter tosId
		Use this parameter to specify the TOS ID of the specified destination IP. Applicable only when the -tos is enabled Minimum value: 1 Maximum value: 63
	.Parameter secure
		The state of the secure monitoring of services. SSL handshake will be done on the TCP connection established. Applicable only for TCP based monitors. This option can't be used in conjuction with CITRIX-AG monitor as this monitor is a secure monitor by default. Possible values: YES, NO Default value: NO
	.Parameter validateCred
		Setting this field causes the monitor to send probe which validate the credentials of the Xen Desktop DDC. Possible values: YES, NO Default value: NO
	.Parameter domain
		Domain name required by the monitors. This is for the Xen Desktop DDC monitor to validate the credentials and CITRIX-WI-EXTENDED monitor for logon process.
	.Parameter IPAddress
		List of IP address to be checked against the response to the DNS monitoring probe. Applicable only to the DNS monitors.
	.Parameter group
		Group name to be queried for NNTP monitor.
	.Parameter fileName
		File name to be used for FTP-EXTENDED monitor.
	.Parameter baseDN
		Base name for the LDAP monitor.
	.Parameter bindDN
		BDN name for the LDAP monitor.
	.Parameter filter
		Filter for the LDAP monitor.
	.Parameter attribute
		Attribute for the LDAP monitor.
	.Parameter database
		Database to be used for the MYSQL/MSSQL monitor.
	.Parameter sqlQuery
		SQL query to be used for the MYSQL/MSSQL monitor.
	.Parameter evalRule
		Rule evaluated to determine the state of MYSQL/MSSQL monitor.
	.Parameter mssqlProtocolVersion
		Protocol Version used by MSSQL monitor Possible values: 70, 2000, 2000SP1, 2005, 2008, 2008R2 Default value: TDS_PROT_70
	.Parameter snmpOID
		OID to be used for the SNMP monitor.
	.Parameter snmpCommunity
		Community to be used for the SNMP monitor.
	.Parameter snmpThreshold
		Threshold to be used for the SNMP monitor.
	.Parameter snmpVersion
		SNMP version to be used for LOAD monitoring. Possible values: V1, V2
	.Parameter metricTable
		Metric table to use for the metrics that are going to be bound.
	.Parameter application
		Name of the application that has to be executed to check the state of the service
	.Parameter sitePath
		URL of the logon page. To get the dynamic page under sitepath, this sitepath must be specified ending with "/".
	.Parameter netProfile
		The name of the network profile.
	.Parameter originHost
		Origin Host to be put in CER message.
	.Parameter originRealm
		Origin realm to be put in CER message.
	.Parameter hostIPAddress
		Host IP Address to be put in CER message.
	.Parameter vendorId
		Vendor ID to be put in CER message.
	.Parameter productName
		Product Name to be put in CER message.
	.Parameter firmwareRevision
		FIRMWARE-REVISION to be put in CER message.
	.Parameter authApplicationId
		list of Auth-Application-Ids to be put in CER message. maximum 8 such auth application id are supported in monitoring message. Maximum value: 4294967295
	.Parameter acctApplicationId
		list of ACCT-APPLICATION-IDs to be put in CER message. maximum 8 such acct application id are supported in monitoring message. Maximum value: 4294967295
	.Parameter inbandSecurityId
		INBAND-SECURITY-ID to be put in CER message. Possible values: NO_INBAND_SECURITY, TLS
	.Parameter supportedVendorIds
		list of SUPPORTED-VENDOR-ID to be put in CER message. maximum 8 such supported Vendor id are supported in monitoring message. Minimum value: 1 Maximum value: 4294967295
	.Parameter vendorSpecificVendorId
		Vendor Id to be used in Vendor-Specific-Application-Id in monitoring CER message. Only 1 such vendor id is supported. Minimum value: 1
	.Parameter WebSession
		An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-Monitor -NSIP 10.108.151.1 -monitorName http_mon -type http -WebSession $session
    #>
	[CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $MonitorName,
	[Parameter(Mandatory=$true)][string] $Type,
	[Parameter(Mandatory=$false)][string] $LRTM,
	[Parameter(Mandatory=$false)][string] $DestIP,
    [Parameter(Mandatory=$true)] $WebSession
	)
	
	$payload = @{monitorName=$MonitorName;type=$Type;LRTM=$LRTM;destIP=$DestIP}
	$Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType lbmonitor -WebSession $WebSession -Payload $payload -Action add
}

function Add-Service {
<#
	.SYNOPSIS
		Create a service
	.DESCRIPTION
		Create a service
	.Parameter name
		Name of the service. The name must not exceed 127 characters, and the leading character must be a number or letter. The following characters are also allowed: @ _ - . (period) : (colon) # and space ( ).
	.Parameter serverName
		Name of the monitor
	.Parameter serviceType
		The type of connections that the service will handle. Possible values: HTTP, FTP, TCP, UDP, SSL, SSL_BRIDGE, SSL_TCP, NNTP, RPCSVR, DNS, ADNS, SNMP, RTSP, DHCPRA, ANY, SIP_UDP, DNS_TCP, ADNS_TCP, RADIUS, MYSQL, MSSQL, and RDP. Default: HTTP.
	.Parameter port
		Port on which the service listens. The port number must be a positive number not greater than 65534.
	.Parameter WebSession
		An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
	.EXAMPLE
		Add-Service -NSIP 10.108.151.1 -name dummy_service -serverName 1.2.3.4 -serviceType HTTP -port 80 -WebSession $session
	#>
	[CmdletBinding()]
	param(
	[Parameter(Mandatory=$true)][string] $NSIP,
	[Parameter(Mandatory=$true)][string] $Name,
    [Parameter(Mandatory=$true)][string] $ServerName,
	[Parameter(Mandatory=$true)][string] $ServiceType,
	[Parameter(Mandatory=$true)][int] $Port,
    [Parameter(Mandatory=$true)] $WebSession
	)
	$payload = @{name=$Name;serverName=$ServerName;serviceType=$ServiceType;port=$Port}
	$Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType service -WebSession $WebSession -Payload $payload -Action add
}

function Add-Server {
<#
	.SYNOPSIS
		Create a server (Incomplete Implementation)
    .Parameter name
        The name assigned to the server. This alphanumeric string is required. The name must not exceed 127 characters, and the leading character must be a number or letter. The following characters are also allowed: @ _ - . (period) : (colon) # and space ( ).
    .Parameter ipAddress
        IP address of the server, in either IPv4 or IPv6 format.
        If the server is not reachable from the appliance or is not active, the service is marked as DOWN.
    .Parameter domain
        Domain name that resolves to the IP address that represents the server.
    .Parameter ipv6Address
        Resolve the domain name to an IPv6 address. Possible values: YES, NO. Default: NO.
    .Parameter translationIp
        The IP address used for translating dns obtained ip.
    .Parameter domainResolveRetry
        The duration in seconds for which NetScaler system waits to send the next dns query to resolve the domain name, in case the last query failed. If last query succeeds, the netscaler system waits for TTL time in the response. Default value: 5 Minimum value: 5 Maximum value: 20939
    .Parameter state
        The initial state of the server. Possible values: ENABLED, DISABLED. Default: ENABLED.
    .Parameter comment
        A comment to help identify the server. Maximum length: 255 characters. To include spaces in a comment that you type on the command line, enclose the entire comment inside quotation marks. The quotation marks become part of the comment. They are not required if you use the configuration utility.
    .Example
        Add-Server -name myserver -state ENABLED
    #>
    [CmdletBinding()]
	param(
	[Parameter(Mandatory=$true)][string] $NSIP,
	[Parameter(Mandatory=$true)][string] $Name,
    [Parameter(Mandatory=$true)][string] $IPaddress,
    [Parameter(Mandatory=$false)][string] $Domain,
    [Parameter(Mandatory=$false)][string] $IPV6Address,
    [Parameter(Mandatory=$false)][string] $TranslationIP,
    [Parameter(Mandatory=$false)][int] $DomainResolveRetry,
    [Parameter(Mandatory=$false)][string] $State,
    [Parameter(Mandatory=$false)][string] $Comment,
	[Parameter(Mandatory=$true)] $WebSession
	)
    $payload = @{name=$Name;IPAddress=$IPaddress}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType server -WebSession $WebSession -Payload $payload -Action add
}

function Add-MonitorServiceBinding {
<#
	.SYNOPSIS
		Bind a service with a monitor
	.DESCRIPTION
		Bind a service with a monitor
	.Parameter ServiceName
		Name of the service. The name must not exceed 127 characters, and the leading character must be a number or letter. The following characters are also allowed: @ _ - . (period) : (colon) # and space ( ).
	.Parameter MonitorName
		Name of the monitor
	.Parameter WebSession
		An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
	.EXAMPLE
		Add-MonitorServiceBinding -ServiceName testservice -MonitorName monitor -WebSession $session
	#>
	[CmdletBinding()]
	param(
	[Parameter(Mandatory=$true)][string] $NSIP,
	[Parameter(Mandatory=$true)][string] $MonitorName,
    [Parameter(Mandatory=$true)][string] $ServiceName,
	[Parameter(Mandatory=$true)] $WebSession
	)
	$payload = @{monitorName=$MonitorName;ServiceName=$ServiceName}
	$Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType lbmonitor -WebSession $WebSession -Payload $payload -Action bind
}

function Add-LBVserver {
<#
	.SYNOPSIS
		Create a load balancing virtual server (Incomplete Implementation)
	.DESCRIPTION
		Create a load balancing virtual server (Incomplete Implementation)
	.Parameter Name
		The name of the load balancing virtual server being added.
	.Parameter ServiceType
		The service type. Possible values: HTTP, FTP, TCP, UDP, SSL, SSL_BRIDGE, SSL_TCP, NNTP, DNS, DHCPRA, ANY, SIP_UDP, DNS_TCP, RTSP, PUSH, SSL_PUSH, RADIUS, RDP, MYSQL, MSSQL, DIAMETER, SSL_DIAMETER
	.Parameter IPAddress
		The IP address of the virtual server.
	.Parameter IPPattern
		The IP Pattern of the virtual server.
	.Parameter port
		A port number for the virtual server.
	.Parameter range
		The IP range for the network vserver. Default value: 1 Minimum value: 1 Maximum value: 254
	.Parameter persistenceType
		Persistence type for the virtual server. Note: The <persistenceType> parameter can take one of the following options: SOURCEIP - When configured, the system selects a physical service based on the Load Balancing method, and then directs all the subsequent requests arriving from the same IP as the first request to the same physical service. COOKIEINSERT - When configured, the system inserts an HTTP cookie into the client responses. The cookie is inserted into the "Cookie" header field of the HTTP response. The client stores the cookie (if enabled) and includes it in all the subsequent requests, which then match the cookie criteria. The cookie contains information about the service where the requests have to be sent. SSLSESSION ID - When configured, the system creates a persistence that is session based on the arriving SSL Session ID, which is part of the SSL handshake process. All requests with the same SSL session ID are directed to the initially selected physical service. CUSTOM SERVER ID -This mode of Persistence requires the server to provide its Server-ID in such a way that it can be extracted from subsequent requests. The system extracts the Server-ID from subsequent client requests and uses it to select a server. The server embeds the Server-ID into the URL query of the HTML links, accessible from the initial page that has to generate persistent HTTP requests. RULE - When configured, the system maintains persistence based on the contents of the matched rule. This persistence requires an expression to be configured. The expression is created using the add expression CLI command and is configured on a virtual server, using the -rule option of the add lb vserver or set lb vserver CLI command.After successful evaluation of the expression, a persistence session is created and all subsequent matching client requests are directed to the previously selected server. URLPASSIVE - This mode of Persistence requires the server to provide its Server-ID in such a way that it can be extracted from subsequent requests.The system extracts the Server-ID from subsequent client requests and uses it to select a server. The servers which require persistence, embed the Server-ID into the URL query of the HTML links, accessible from the initial page. The Server-ID is its IP address and port specified as a hexadecimal number.URL Passive persistence type requires an expression to be configured that specifies the location of the Server-ID in the client's requests. The expression is created using the CLI command add expression. This expression is configured on a virtual server, using option -rule of the add lb vserver or set lb vserver CLI command. DESTIP -When configured, the system selects a physical service based on the Load Balancing method, and then directs all the subsequent requests with the same destination as the first packet to the same physical service. This will be used in LLB deployment scenarios. SRCIPDESTIP - When configured, the system selects a physical service based on the Load Balancing method, and then directs all the subsequent requests with the same Source IP and Destination IP as the first packet to the same physical service. This will be used in IDS LB depolyments. CALLID - When configured, the system maintains persistence based on CALLID used in the SIP transactions. All the SIP transactions with same CALLID are directed to the same server. RTSPSID - When configured, the system maintains persistence based on RTSP sessionID provided by the server. The client also sends the same RTSP sessionID in the subsequent requests which are then directed to the same server. DIAMETER - When configured, the system mantains persistence based on an AVP code value found in Diameter Message. This persistence requires an AVP code to be configured as persist AVP code. This persist Avp Code is configured in cli using using option -persistAVPno. After successfully finding persist AVP code in diameter request, a persistence session is created with AVP contents and all subsequent matching Diameter messages are directed to the previously selected server. Possible values: SOURCEIP, COOKIEINSERT, SSLSESSION, RULE, URLPASSIVE, CUSTOMSERVERID, DESTIP, SRCIPDESTIP, CALLID, RTSPSID, DIAMETER, NONE
	.Parameter timeout
		The time period for which the persistence is in effect for a specific client. The value ranges from 2 to 1440 minutes. Default value: 2 Maximum value: 1440
	.Parameter persistenceBackup
		Use this parameter to specify a backup persistence type for the virtual server. The Backup persistence option is used when the primary configured persistence mechanism on virtual server fails. The <persistenceBacup> parameter can take one of the following options: SOURCEIP NONE Possible values: SOURCEIP, NONE
	.Parameter ownerNode
		The owner node. Maximum value: 31
	.Parameter backupPersistenceTimeout
		The maximum time backup persistence is in effect for a specific client. Default value: 2 Minimum value: 2 Maximum value: 1440
	.Parameter lbMethod
		The load balancing method for the virtual server. The valid options for this parameter are: ROUNDROBIN, LEASTCONNECTION, LEASTRESPONSETIME, URLHASH, DOMAINHASH, DESTINATIONIPHASH, SOURCEIPHASH, SRCIPDESTIPHASH,LEASTBANDWIDTH, LEASTPACKETS, TOKEN, SRCIPDESTIPHASH, CUSTOMLOAD, SRCIPSRCPORTHASH, LRTM, CALLIDHASSH. When the load balancing policy is configured as: ROUNDROBIN - When configured, the system distributes incoming requests to each server in rotation, regardless of the load. When different weights are assigned to services then weighted round robin occurs and requests go to services according to how much weighting has been set. LEASTCONNECTION (default value)- When configured, the system selects the service that has the least number of connections. For TCP, HTTP, HTTPS and SSL_TCP services the least number of connections includes: Established, active connections to a service. Connection reuse applies to HTTP and HTTPS. Hence the count includes only those connections which have outstanding HTTP or HTTPS requests, and does not include inactive, reusable connections. Connections to a service waiting in the Surge Queue, which exists only if the Surge Protection feature is enabled. For UDP services the least number of connections includes: The number of sessions between client and a physical service. These sessions are the logical, time-based entities, created on first arriving UDP packet. If configured, weights are taken into account when server selection is performed. LEASTRESPONSETIME - When configured, the system selects the service with the minimum average response time. The response time is the time interval taken when a request is sent to a service and first response packet comes back from the service, that is Time to First Byte (TTFB). URLHASH - The system selects the service based on the hashed value of the incoming URL.To specify the number of bytes of the URL that is used to calculate the hash value use the optional argument [-hashLength <positive_integer>] in either the add lb vserver or set lb vserver CLI command. The default value is 80. DOMAINHASH - When configured with this load balancing method, the system selects the service based on the hashed value of the domain name in the HTTP request. The domain name is taken either from the incoming URL or from the Host header of the HTTP request. Note:	The system defaults to LEASTCONNECTION if the request does not contain a domain name. If the domain name appears in both the URL and the host header, the system gives preference to the URL domain. DESTINATIONIPHASH - The system selects the service based on the hashed value of the destination IP address in the TCP IP header. SOURCEIPHASH - The system selects the service based on the hashed value of the client's IP address in the IP header. LEASTBANDWIDTH - The system selects the service that is currently serving the least traffic, measured in megabits per second. LEASTPACKETS - The system selects the service that is currently serving the lowest number of packets per second. Token -The system selects the service based on the value, calculated from a token, extracted from the client's request (location and size of the token is configurable or by evaluating the rule configured). For subsequent requests with the same token, the systems will select the same physical server. SRCIPDESTIPHASH - The system selects the service based on the hashed value of the client's SOURCE IP and DESTINATION IP address in the TCP IP header. CUSTOMLOAD - The system selects the service based on the it load which was determined by the LOAD monitors bound to the service. SRCIPSRCPORTHASH - The system selects the service based on the hashed value of the client's SOURCE IP and SOURCE PORT in the TCP/UDP+IP header. LRTM - When configured, the system selects the service with least response time learned through probing(number of active connections taken into account in addition to the response time). CALLIDHASSH - The system selects the service based on the hashed value of SIP callid. Possible values: ROUNDROBIN, LEASTCONNECTION, LEASTRESPONSETIME, URLHASH, DOMAINHASH, DESTINATIONIPHASH, SOURCEIPHASH, SRCIPDESTIPHASH, LEASTBANDWIDTH, LEASTPACKETS, TOKEN, SRCIPSRCPORTHASH, LRTM, CALLIDHASH, CUSTOMLOAD, LEASTREQUEST Default value: PEMGMT_LB_LEASTCONNS
	.Parameter rule
		Use this parameter to specify the string value used to set the RULE persistence type. The string can be either an existing rule name (configured using add expression command) or else it can be an in-line expression with a maximum of 1499 characters. Default value: "none"
	.Parameter Listenpolicy
		Use this parameter to specify the listen policy for LB Vserver. The string can be either an existing expression name (configured using add policy expression command) or else it can be an in-line expression with a maximum of 1499 characters. Default value: "none"
	.Parameter Listenpriority
		Use this parameter to specify the priority for listen policy of LB Vserver. Default value: 101 Maximum value: 101
	.Parameter resRule
		Use this parameter to specify the expression to be used in response for RULE persistence type. The string is an in-line expression with a maximum of 1499 characters. Default value: "none"
	.Parameter persistMask
		Use this parameter to specify if the persistency is IP based. This parameter is Optional. Default value: 0xFFFFFFFF
	.Parameter v6persistmasklen
		The persistence mask. Use this parameter if you are using IP based persistence type on a ipv6 vserver. Default value: 128 Minimum value: 1 Maximum value: 128
	.Parameter pq
		Use this parameter to enable priority queuing on the specified virtual server. Possible values: ON, OFF Default value: OFF
	.Parameter sc
		Use this parameter to enable SureConnect on the specified virtual server. Possible values: ON, OFF Default value: OFF
	.Parameter rtspNat
		Use this parameter to enable natting for RTSP data connection. Possible values: ON, OFF Default value: OFF
	.Parameter m
		Use this parameter to specify the LB mode. If the value is specified as IP then the traffic is sent to the physical servers by changing the destination IP address to that of the physical server. If the value is MAC then the traffic is sent to the physical servers , by changing the destination MAC address to that of one of the physical servers, the destination IP is not changed. MAC mode is used mostly in Firewall Load Balancing scenario. Possible values: IP, MAC, IPTUNNEL, TOS Default value: NSFWD_IP
	.Parameter tosId
		Use this parameter to specify the TOS ID of this vserver. Applicable only when the LB mode is TOS Minimum value: 1 Maximum value: 63
	.Parameter dataLength
		Use this parameter to specify the length of the token in bytes. Applicable to TCP virtual servers, when Token Load Balancing method is selected. The datalength should not be more than 24k. Maximum value: 100
	.Parameter dataOffset
		Use this parameter to specifies offset of the data to be taken as token. Applicable to the TCP type virtual servers, when Token load balancing method is used. Must be within the first 24k of the client TCP data. Maximum value: 25400
	.Parameter sessionless
		Use this parameter to enable sessionless load balancing. Possible values: ENABLED, DISABLED Default value: DISABLED
	.Parameter state
		The state of the load balancing virtual server. Possible values: ENABLED, DISABLED Default value: ENABLED
	.Parameter connfailover
		Specifies the connection failover mode of the virtual server Possible values: DISABLED, STATEFUL, STATELESS Default value: DISABLED
	.Parameter redirectURL
		The URL where traffic is redirected if the virtual server in the system becomes unavailable. You can enter up to 127 characters as the URL argument. WARNING!	Make sure that the domain you specify in the URL does not match the domain specified in the -d domainName argument of the add cs policy CLI command. If the same domain is specified in both arguments, the request will be continuously redirected to the same unavailable virtual server in the system - then the user may not get the requested content.
	.Parameter cacheable
		Use this option to specify whether a virtual server, used for load balancing or content switching, routes requests to the cache redirection virtual server before sending it to the configured servers. Possible values: YES, NO Default value: NO
	.Parameter cltTimeout
		The timeout value in seconds for idle client connection Default value: VAL_NOT_SET Maximum value: 31536000
	.Parameter soMethod
		The spillover factor based on which the traffic will be given to the backupvserver once the main virtual server reaches the spillover threshold. Possible values: CONNECTION, DYNAMICCONNECTION, BANDWIDTH, HEALTH, NONE
	.Parameter soPersistence
		The state of the spillover persistence. Possible values: ENABLED, DISABLED Default value: DISABLED
	.Parameter soPersistenceTimeOut
		The spillover persistency entry timeout. Default value: 2 Minimum value: 2 Maximum value: 1440
	.Parameter soThreshold
		In case of CONNECTION (or) DYNAMICCONNECTION type spillover method this value is treated as Maximum number of connections an lb vserver will handle before spillover takes place. In case of BANDWIDTH type spillover method this value is treated as the amount of incoming and outgoing traffic (in Kbps) a Vserver will handle before spillover takes place. In case of HEALTH type spillover method if the percentage of active services (by weight) becomes lower than this value, spillover takes place Minimum value: 1 Maximum value: 4294967287
	.Parameter redirectPortRewrite
		The state of port rewrite while performing HTTP redirect. Possible values: ENABLED, DISABLED Default value: DISABLED
	.Parameter downStateFlush
		Perform delayed clean up of connections on this vserver. Possible values: ENABLED, DISABLED Default value: ENABLED
	.Parameter backupVServer
		The Backup Virtual Server.
	.Parameter disablePrimaryOnDown
		When this argument is enabled, traffic will continue reaching backup vservers even after primary comes UP from DOWN state. Possible values: ENABLED, DISABLED Default value: DISABLED
	.Parameter insertVserverIPPort
		The virtual IP and port header insertion option for the vserver. VIPADDR	- Header contains the vserver's IP address and port number without any translation. OFF	- The virtual IP and port header insertion option is disabled. V6TOV4MAPPING - Header contains the mapped IPv4 address corresponding to the IPv6 address of the vserver and the port number. An IPv6 address can be mapped to a user-specified IPv4 address using the set ns ip6 command. Possible values: OFF, VIPADDR, V6TOV4MAPPING
	.Parameter AuthenticationHost
		FQDN of authentication vserver
	.Parameter Authentication
		This option toggles on or off the application of authentication of incoming users to the vserver. Possible values: ON, OFF Default value: OFF
	.Parameter authn401
		This option toggles on or off the HTTP 401 response based authentication. Possible values: ON, OFF Default value: OFF
	.Parameter authnVsName
		Name of authentication vserver
	.Parameter push
		Process traffic on bound Push vserver. Possible values: ENABLED, DISABLED Default value: DISABLED
	.Parameter pushVserver
		The lb vserver of type PUSH/SSL_PUSH to which server pushes the updates received on the client facing non-push lb vserver.
	.Parameter pushLabel
		Use this parameter to specify the expression to extract the label in response from server. The string can be either a named expression (configured using add policy expression command) or else it can be an in-line expression with a maximum of 63 characters. Default value: "none"
	.Parameter pushMultiClients
		Specify if multiple web 2.0 connections from the same client can connect to this vserver and expect updates. Possible values: YES, NO Default value: NO
	.Parameter tcpProfileName
		The name of the TCP profile.
	.Parameter httpProfileName
		Name of the HTTP profile.
	.Parameter comment
		Comments associated with this virtual server.
	.Parameter l2Conn
		Use L2 Parameters to identify a connection Possible values: ON, OFF
	.Parameter mssqlServerVersion
		The version of the MSSQL server Possible values: 70, 2000, 2000SP1, 2005, 2008, 2008R2 Default value: TDS_PROT_2008B
	.Parameter mysqlProtocolVersion
		The protocol version returned by the mysql vserver. Default value: NSA_MYSQL_PROTOCOL_VER_DEFAULT
	.Parameter mysqlServerVersion
		The server version string returned by the mysql vserver. Default value: NSA_MYSQL_SERVER_VER_DEFAULT
	.Parameter mysqlCharacterSet
		The character set returned by the mysql vserver. Default value: NSA_MYSQL_CHAR_SET_DEFAULT
	.Parameter mysqlServerCapabilities
		The server capabilities returned by the mysql vserver. Default value: NSA_MYSQL_SVR_CAPABILITIES_DEFAULT
	.Parameter appflowLog
		Enable logging appflow flow information Possible values: ENABLED, DISABLED Default value: ENABLED
	.Parameter netProfile
		The name of the network profile.
	.Parameter icmpVsrResponse
		Can be active or passive Possible values: PASSIVE, ACTIVE Default value: NS_VSR_PASSIVE
	.Parameter newServiceRequest
		The number of requests/sec or percentage of requests/sec a new service should receive compared to the existing services. The maximum possible value for requests/sec is 65536 and percentage of requests is 100
	.Parameter newServiceRequestIncrementInterval
		The interval in seconds after which the new services requests limit should be automatically increased. Maximum value: 3600
	.Parameter persistAVPno
		Persist AVP number for Diameter Persistency. In case this AVP is not defined in Base RFC 3588 and it is nested inside a Grouped AVP, define a sequence of AVP numbers (max 3) in order of parent to child. So say persist AVP number X is nested inside AVP Y which is nested in Z, then define the list as Z Y X Minimum value: 1
	.Parameter WebSession
		An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
	.EXAMPLE
		Add-LBVserver -NSIP '10.0.0.100' -Name http_server -ServiceType HTTP -IPAddress 10.0.1.175 -port 80 -persistenceType COOKIEINSERT -timeout 0 -cltTimeout 180 -WebSession $session
	#>
	[CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $Name,
	[Parameter(Mandatory=$true)][string] $ServiceType,
	[Parameter(Mandatory=$true)][string] $IpAddress,
	[Parameter(Mandatory=$true)][int] $Port,
	[Parameter(Mandatory=$true)][string] $PersistenceType,
	[Parameter(Mandatory=$true)][int] $Timeout,
	[Parameter(Mandatory=$true)][int] $CltTimeout,
    [Parameter(Mandatory=$true)] $WebSession
	)
	$payload = @{name=$Name;serviceType=$ServiceType;ipv46=$IpAddress;port=$Port;persistenceType=$PersistenceType;timeout=$Timeout;cltTimeout=$CltTimeout}
	$Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType lbvserver -WebSession $WebSession -Payload $payload -Action add
}

function Add-LBVServerServiceBinding {
<#
    .SYNOPSIS
        Create a binding between LB VServer and Service
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Create a binding between LB Vserver and Service
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter LBVServerName
	    Name of the LBVServer
	.Parameter ServiceName
		Name of the Service
	.Parameter WebSession
		An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-LBVServerServiceBinding -NSIP 10.0.1.100 -LBVServerName http_server -ServiceName Always_UP_service -WebSession $session
    #>
	[CmdletBinding()]
	param(
	[Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $LBVServerName,
	[Parameter(Mandatory=$true)][string] $ServiceName,
	[Parameter(Mandatory=$true)] $WebSession
	)
	$payload = @{name=$LBVServerName;serviceName=$ServiceName}
	$Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType lbvserver -WebSession $WebSession -Payload $payload -Action bind
}

function Add-LBVServerPolicyBinding {
<#
	.SYNOPSIS
        Create a binding between LB VServer and Policy
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Create a binding between LB Vserver and Policy
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter LBVServerName
	    Name of the LBVServer
	.Parameter PolicyName
		Name of the Policy
	.Parameter Priority
		Priority level for the policy
	.Parameter GotoPriorityExpression
		Provide an expression for the priority
	.Parameter WebSession
		An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-LBVServerPolicyBinding -NSIP 10.0.1.100 -LBVServerName http_server -PolicyName http_to_https -Priority 1 -GotoPriorityExpression END -WebSession $session
    #>
	[CmdletBinding()]
	param(
	[Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $LBVServerName,
	[Parameter(Mandatory=$true)][string] $PolicyName,
	[Parameter(Mandatory=$true)][int] $Priority,
	[Parameter(Mandatory=$true)][string] $GotoPriorityExpression,
	[Parameter(Mandatory=$true)] $WebSession
	)
	$payload = @{name=$LBVServerName;policyName=$PolicyName;priority=$Priority;gotoPriorityExpression=$GotoPriorityExpression}
	$Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType lbvserver -WebSession $WebSession -Payload $payload -Action bind
}

function Set-UItheme {
<#
    .SYNOPSIS
        Set the UI theme of the Netscaler Gateway 
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Set the UI theme of the NetScaler Gateway
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter Theme
	    Name of the theme
	.Parameter WebSession
		An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Set-UItheme -NSIP 10.108.151.1 -Theme GreenBubble -WebSession $session
    #>
	[CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $Theme,
    [Parameter(Mandatory=$true)] $WebSession
	)
	$payload = @{uitheme=$Theme}
	$Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType vpnparameter -WebSession $WebSession -Payload $payload -Action set
}

function Add-Route {
<#
    .SYNOPSIS
        Add a static route in NetScaler
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add a static route in NetScaler
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter Network
        IP address of the network to which the route is being added
    .Parameter SubnetMask
        Subnet Mask of the network to which the route is being added.  
    .Parameter Gateway
        Gateway to be used when communicating with this network
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-Route -NSIP 10.108.151.1 -Network "192.168.0.0" -SubnetMask "255.255.0.0" -Gateway "10.0.5.1" -WebSession $session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $Network,
    [Parameter(Mandatory=$true)][string] $SubnetMask,
    [Parameter(Mandatory=$true)][string] $Gateway,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{network=$Network;netmask=$SubnetMask;gateway=$Gateway}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType route -WebSession $WebSession -Payload $payload -Action add
}


function Add-LinkCert {
    <#
    .SYNOPSIS
        Link two certificates
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Link two SSL certificates
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter CertName
        Name for the certificate and private-key pair. 
    .Parameter LinkCertName
        Name of the Certificate to be linked. 
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-LinkCert -NSIP 10.108.151.1 -CertName "server_certificate" -LinkCertName "Root_certificate" -WebSession $session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $CertName,
    [Parameter(Mandatory=$true)][string] $LinkCertName,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{certkey=$CertName;linkCertKeyName=$LinkCertName}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType sslcertkey -WebSession $WebSession -Payload $payload -Action link 

}

function New-VServeSSLCertKeyBinding {
    <#
    .SYNOPSIS
        Bind a SSL certificate-key pair to a virtual server
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Bind a SSL certificate-key pair to a virtual server
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter CertKeyName
        Name of the certificate key pair
    .Parameter VServerName
        Name of the virtual server
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        New-VServeSSLCertKeyBinding -NSIP 10.108.151.1 -CertKeyName "*.xd.local" -VServerName myvs -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $CertKeyName,
    [Parameter(Mandatory=$true)][string] $VServerName,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload =  @{certkeyname=$CertKeyName;vservername=$VServerName}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod put -ResourceType sslvserver_sslcertkey_binding -WebSession $WebSession -Payload $payload -Action add 

}


function Add-VServer {
    <#
    .SYNOPSIS
        Add a new virtual server
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add a new virtual server
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter VServerName
        Name of the virtual server
    .Parameter VServerIP
        IPv4 or IPv6 address of the Access Gateway virtual server. 
        Usually a public IP address. User devices send connection requests to this IP address.
    .Parameter VServerPort
        TCP port on which the virtual server listens, default to 433
    .Parameter ICAOnly
        User can log on in basic mode only, through either Citrix Receiver or a browser. Users are not allowed to connect by using the Access Gateway Plug-in.
    .Parameter VServerIP
        IP address of the virtual server
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-VServer -NSIP 10.018.151.1 -VServerName myvs -VServerIP 10.108.151.3 -VServerPort 443 -ICAOnly -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $VServerName,
    [Parameter(Mandatory=$true)][string] $VServerIP,
    [Parameter(Mandatory=$false)][int] $VServerPort=443,
    [Parameter(Mandatory=$false)][switch] $ICAOnly=$false,
    #[Parameter(Mandatory=$false)][string] $CertKeyName,
    #[Parameter(Mandatory=$true)][string] $LDAPPolicyName,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $ica = @{$true="YES";$false="NO"}[ $ICAOnly -eq $true]
    $payload = @{name=$VServerName;ipv46=$VServerIP;port=$VServerPort;icaonly=$ica;servicetype="ssl"}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType vpnvserver -WebSession $WebSession -Payload $payload -Action add 
   
    #New-VServeSSLCertKeyBinding -NSIP $NSIP -CertKeyName $CertKeyName -VServerName $VServerName -WebSession $WebSession

    #New-VServerLDAPPolicyBinding -NSIP $NSIP -VServerName $VServerName -LDAPPolicyName $LDAPPolicyName -WebSession $WebSession

}

function Add-LDAPAction {
    <#
    .SYNOPSIS
        Add a new LDAP action
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add a new LDAP action
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter LDAPActionName
        Name of the LDAP action
    .Parameter LDAPServerIP
        IP address assigned to the LDAP server.
    .Parameter LDAPBaseDN
        Base (node) from which to start LDAP searches. 
        If the LDAP server is running locally, the default value of base is dc=netscaler, dc=com.
    .Parameter LDAPBindDN
        Full distinguished name (DN) that is used to bind to the LDAP server. Default: cn=Manager,dc=netscaler,dc=com.  
    .Parameter LDAPBindDNPassword,
        Password used to bind to the LDAP server.
    .Parameter LDAPLoginName
        LDAP login name attribute. Default to "sAMAccountName"
        The NetScaler appliance uses the LDAP login name to query external LDAP servers or Active Directories.
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-LDAPAction -NSIP 10.108.151.1 -LDAPActionName "10.108.151.1_LDAP" -LDAPServerIP 10.8.115.245 -LDAPBaseDN "dc=xd,dc=local" -LDAPBindDN "administrator@xd.local" -LDAPBindDNPassword citrix  -LDAPLoginName sAMAccountName -WebSession $session 
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $LDAPActionName,
    [Parameter(Mandatory=$true)][string] $LDAPServerIP,
    [Parameter(Mandatory=$true)][string] $LDAPBaseDN,
    [Parameter(Mandatory=$true)][string] $LDAPBindDN,
    [Parameter(Mandatory=$true)][string] $LDAPBindDNPassword,
    [Parameter(Mandatory=$false)][string] $LDAPLoginName="sAMAccountName",
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload =  @{name=$LDAPActionName;serverip=$LDAPServerIP;ldapbase=$LDAPBaseDN;ldapbinddn=$LDAPBindDN;ldapbinddnpassword=$LDAPBindDNPassword;ldaploginname=$LDAPLoginName}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType authenticationldapaction -WebSession $WebSession -Payload $payload -Action add 

}

function Add-LDAPPolicy {
    <#
    .SYNOPSIS
        Add a new LDAP policy
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add a new LDAP policy
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter LDAPActionName
        Name of the LDAP action to perform if the policy matches.
    .Parameter LDAPPolicyName
        Name of the LDAP policy
    .Parameter LDAPRuleExpression
        Name of the NetScaler named rule, or a default syntax expression, that the policy uses to determine whether to attempt to authenticate the user with the LDAP server.
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
	    Add-LDAPPolicy -NSIP 10.108.151.1 -LDAPActionName "10.8.115.245_LDAP" -LDAPPolicyName "10.8.115.245_LDAP_pol" -LDAPRuleExpression NS_TRUE -WebSession $session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $LDAPActionName,
    [Parameter(Mandatory=$true)][string] $LDAPPolicyName,
    [Parameter(Mandatory=$true)][string] $LDAPRuleExpression,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{reqaction=$LDAPActionName;name=$LDAPPolicyName;rule=$LDAPRuleExpression}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType authenticationldappolicy -WebSession $WebSession -Payload $payload -Action add 

}

function New-VServerLDAPPolicyBinding {
    <#
    .SYNOPSIS
        Bind authenticationldappolicy to vpnvserver.
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Bind authenticationldappolicy to vpnvserver.
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter VServerName
        Name of the virtual server.
    .Parameter LDAPPolicyName
        The name of the policy bound to the vpn vserver.
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        New-VServerLDAPPolicyBinding -NSIP 10.108.151.1 -VServerName myvs -LDAPPolicyName "10.108.151.1_LDAP_pol" -WebSession $session

    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $VServerName,
    [Parameter(Mandatory=$true)][string] $LDAPPolicyName,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{name=$VServerName;policy=$LDAPPolicyName}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod put -ResourceType vpnvserver_authenticationldappolicy_binding -WebSession $WebSession -Payload $payload -Action add 

}


function Add-DNSServer {
    <#
    .SYNOPSIS
        Add domain name server resource
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add domain name server resource
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter DNSServerIP
        IP address of an name server, accept value from pipeline
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        [string[]]$DNSServers = @("10.8.115.210","10.8.115.211")
        $DNSServers | Add-DNSServer -NSIP $environmentDescriptor.NetScalerIP -WebSession $session 

    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)] $DNSServerIP,
    [Parameter(Mandatory=$true)] $WebSession
    )
    BEGIN {
        Write-Verbose "Invoking function "
    }
    PROCESS {
        $payload = @{ip=$DNSServerIP}
        $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType dnsnameserver -WebSession $WebSession -Payload $payload -Action add
    }
}

function Get-DNSServer {
    <#
    .SYNOPSIS
        Add domain name server resource
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Gets domain name server configured resources
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Get-DNSServer -NSIP $environmentDescriptor.NetScalerIP -WebSession $session 

    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)] $WebSession
    )
    BEGIN {
        Write-Verbose "Invoking function "
    }
    PROCESS {
        $uri = "$($Script:URLProtocol)://$NSIP/nitro/v1/config/dnsnameserver"
        $Job = Invoke-RestMethod -Uri $Uri -ContentType "application/json" -method "Get" -WebSession $WebSession
		$Job
    }
}

function Invoke-NitroAPI {
    <#
    .SYNOPSIS
        Invoke NetScaler NITRO REST API 

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Invoke NetScaler NITRO REST API 
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter OperationMethod
        Specifies the method used for the web request. Acceptable values: "Delete","Get","Post","Put"
    .Parameter ResourceType
        Type of the NS VPX resource
    .Parameter ResourceName
        Name of the NS VPX resource, optional
    .Parameter Action
        Name of the action to perform on the NS VPX resource
    .Parameter Payload
        Payload  of the web request, in hashtable format
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .Parameter ContentType
        Specifies the content type of the web request, default to "application/json"
	.Parameter GetWarning
        Switch parameter, when turned on, warning message will be sent in 'message' field and 'WARNING' value is set in severity field of the response in case there is a warning.
        Turned off by default
	.Parameter OnErrorAction
        Use this parameter to set the onerror status for nitro request. Applicable only for bulk requests.
        Acceptable values: "EXIT", "CONTINUE", "ROLLBACK", default to "EXIT"
    .EXAMPLE
        Invoke NITRO API to add a DNS Server resource.
        $payload = @{ip="10.8.115.210"}
        $Job = Invoke-NitroAPI -NSIP 10.108.151.1 -OperationMethod post -ResourceType dnsnameserver -WebSession $Session -Payload $payload -Action add
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP, 
    [Parameter(Mandatory=$true)][string][ValidateSet("Delete","Get","Post","Put")] $OperationMethod,
    [Parameter(Mandatory=$true)][string] $ResourceType,
    [Parameter(Mandatory=$false)][string] $ResourceName, 
    [Parameter(Mandatory=$false)][string] $Action, 
    [Parameter(Mandatory=$false)][hashtable] $Payload=@{},
    #[Parameter(Mandatory=$false)][string] $SessionId,   
    [Parameter(Mandatory=$true)] $WebSession, 
    [Parameter(Mandatory=$false)][string] $ContentType="application/json",
    [Parameter(Mandatory=$false)][switch] $GetWarning=$false,
    [Parameter(Mandatory=$false)][string][ValidateSet("EXIT", "CONTINUE", "ROLLBACK")] $OnErrorAction="EXIT"
    )
    
    $warning = @{$true="YES";$false="NO"}[ $GetWarning -eq $true]
    $HashtablePayload = @{}
    $HashtablePayload."params" = @{"warning"=$warning;"onerror"=$OnErrorAction;<#"action"=$Action#>}
    $HashtablePayload.$ResourceType = $Payload
    if($ContentType -eq "application/json") {
        $jsonPayload = ConvertTo-Json $HashtablePayload -Depth 6 -Compress
    } else {
        throw "Currently this function only support `"application/json`" content type"
    }
    $uri = "$($Script:URLProtocol)://$NSIP/nitro/v1/config/$ResourceType"
    if(-not [string]::IsNullOrEmpty($ResourceName)) {
        $uri += "/$ResourceName"
    }
    if(-not [string]::IsNullOrEmpty($Action)) {
        $uri += "?action=$Action"
    }
    Write-Verbose $uri
   # return $jsonPayload
    if($WebSession -ne $null) {
        $job = Invoke-RestMethod -Uri $Uri -Body $jsonPayload -ContentType $ContentType -method $OperationMethod -WebSession $WebSession 
    }

    else {

        $job = Invoke-RestMethod -Uri $Uri -Body $jsonPayload -ContentType $ContentType -method $OperationMethod 
    }


   <#if($job.errorcode -ne 0) {
        throw "Function failed with error message $($job.message)"
   }#>

   return $job

}
function Invoke-NetScalerBatchFile {  
    <#
    .SYNOPSIS
        Invoking batch file on NetScaler VPX

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Copy a batch file  to NetScaler VPX and and execute it 
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter NSUserName
        UserName to access the NetScaler Managerment Console, default to nsroot
    .Parameter NSPassword
        Password to access the NetScaler Managerment Console, default to nsroot
    .Parameter LocalPathToBatchFile
        Full path to the batch file
    .EXAMPLE
        Invoke batch file on NetScaler VPX 10.108.151.1
		$fileName = "$($env:temp)\nsAdvanced.conf"
		Invoke-NetScalerBatchFile -NSIP $10.108.151.1 -LocalPathToBatchFile $fileName
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP, 
    [Parameter(Mandatory=$false)][string] $NSUserName="nsroot", 
    [Parameter(Mandatory=$false)][string] $NSPassword="nsroot",
    [Parameter(Mandatory=$true)][string] $LocalPathToBatchFile
    )

    Write-Verbose "Invoking function Invoke-NetScalerBatchFile"
    $scriptName = split-Path $LocalPathToBatchFile -Leaf
    $res = invoke-pscp -Source $LocalPathToBatchFile  -Password $NSPassword -User $NSUserName -Target "$($NSIP):/nsconfig/$scriptName" -Recursive -PreserveFileAttributes

    Write-Verbose "Executing batch file $scriptName on NetScaler VPX $NSIP"
    $myCompoundCommand = "batch -fileName /nsconfig/$scriptName -OutFile /nsconfig/MyOutput2.conf;save ns config"
    Invoke-Plink  -Hostname $NSIP -User $NSUserName -Password $NSPassword -Command $myCompoundCommand | Out-Null
}

function Set-NetScalerSFStore {
    <#
    .SYNOPSIS
        Configure NetScaler to work with an existing StoreFront Site.

        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Configure NetScaler to work with an existing StoreFront Site.. That involves creating session policies and actions and bind them to the virtual server
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter NSUserName
        UserName to access the NetScaler Managerment Console, default to nsroot
    .Parameter NSPassword
        Password to access the NetScaler Managerment Console, default to nsroot
    .Parameter VirtualServerName
        Virtual Server Name
    .Parameter VirtualServerIP
        IPAddress of Virtual Server
    .Parameter StoreFrontServer
        Name or IPAddress of the StoreFront Server
    .Parameter STAServerURL
        STA Server URL, usually the http://[StoreFrontServer]
    .Parameter SingleSignOnDomain
        Single SignOn Domain Name, the same domain is used to autheticate to NetScaler Gateway and pass on to StoreFront
	.Parameter ReceiverForWebPath
        Path to the Receiver For Web Website, default to "/Citrix/StoreWeb"
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
    	Set-NetScalerSFStore -NSIP 10.108.151.1 -VirtualServerName SkynetVS -VirtualServerIP 10.108.151.3 `
        -StoreFrontServer 10.108.156.7 -STAServerURL "http://10.108.156.7" -SingleSignOnDomain xd.local -WebSession $session

    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP, 
    [Parameter(Mandatory=$false)][string] $NSUserName="nsroot", 
    [Parameter(Mandatory=$false)][string] $NSPassword="nsroot",
    [Parameter(Mandatory=$true)][string] $VirtualServerName,
    [Parameter(Mandatory=$true)][string] $VirtualServerIP,
    [Parameter(Mandatory=$true)][string] $StoreFrontServer,
    [Parameter(Mandatory=$true)][string] $STAServerURL,
    [Parameter(Mandatory=$true)][string] $SingleSignOnDomain,
    [Parameter(Mandatory=$false)][string] $ReceiverForWebPath="/Citrix/StoreWeb",
    [Parameter(Mandatory=$true)] $WebSession
       
    )

    Write-Verbose "Invoking  function Set-NetScalerSFStore"

    Add-SessionAction -NSIP $NSIP -SessionActionName AC_OS_$($VirtualServerIP)_S_ -TransparentInterception OFF -SplitTunnel OFF `
    -DefaultAuthorizationAction ALLOW -SSO ON -IcaProxy ON -NtDomain $SingleSignOnDomain -ClientlessVpnMode OFF -ClientChoices OFF `
    -WIHome "https://$StoreFrontServer$ReceiverForWebPath" -StoreFrontUrl "http://$StoreFrontServer" -WebSession $WebSession


    Add-SessionAction -NSIP $NSIP -SessionActionName AC_WB_$($VirtualServerIP)_S_ -TransparentInterception OFF -SplitTunnel OFF `
    -DefaultAuthorizationAction ALLOW -SSO ON -IcaProxy ON -NtDomain $SingleSignOnDomain -ClientlessVpnMode OFF -ClientChoices OFF `
    -WIHome "https://$StoreFrontServer$ReceiverForWebPath" -WebSession $WebSession

    Add-SessionPolicy -NSIP $NSIP -SessionActionName AC_OS_$($VirtualServerIP)_S_ -SessionPolicyName PL_OS_$($VirtualServerIP) `
    -SessionRuleExpression "REQ.HTTP.HEADER User-Agent CONTAINS CitrixReceiver || REQ.HTTP.HEADER Referer NOTEXISTS" -WebSession $WebSession

    Add-SessionPolicy -NSIP $NSIP -SessionActionName AC_WB_$($VirtualServerIP)_S_ -SessionPolicyName PL_WB_$($VirtualServerIP) `
    -SessionRuleExpression "REQ.HTTP.HEADER User-Agent NOTCONTAINS CitrixReceiver && REQ.HTTP.HEADER Referer EXISTS" -WebSession $WebSession

    New-VServeSessionPolicyBinding -NSIP $NSIP -VServerName $VirtualServerName -SessionPolicyName PL_OS_$($VirtualServerIP) -Priority 100 -WebSession $WebSession
    New-VServeSessionPolicyBinding -NSIP $NSIP -VServerName $VirtualServerName -SessionPolicyName PL_WB_$($VirtualServerIP) -Priority 100 -WebSession $WebSession

    New-VServerSTAServerBinding -NSIP $NSIP -VServerName $VirtualServerName -STAServer $STAServerURL -WebSession $WebSession

}


function Add-SessionAction {
    <#
    .SYNOPSIS
        Create VPN session action resource.
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
         Create VPN session action resource.
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter SessionActionName
        Name for the session action
    .Parameter TransparentInterception
        Switch parameter. Allow access to network resources by using a single IP address and subnet mask or a range of IP addresses.
        When turned off,  sets the mode to proxy, in which you configure destination and source IP addresses and port numbers.
        If you are using the NetScale Gateway Plug-in for Windows, turn it on, in which the mode is set to transparent. 
        If you are using the NetScale Gateway Plug-in for Java, turn it off.
    .Parameter SplitTunnel
        Send, through the tunnel, traffic only for intranet applications that are defined in NetScaler Gateway. 
        Route all other traffic directly to the Internet.
        The OFF setting routes all traffic through Access Gateway. 
        With the REVERSE setting, intranet applications define the network traffic that is not intercepted.All network traffic directed to internal IP addresses bypasses the VPN tunnel, while other traffic goes through Access Gateway. 
        Reverse split tunneling can be used to log all non-local LAN traffic. 
        Possible values = ON, OFF, REVERSE
    .Parameter DefaultAuthorizationAction
        Specify the network resources that users have access to when they log on to the internal network. Acceptable vaules: "ALLOW","DENY"
        Default to "DENY", which deny access to all network resources. 
    .Parameter SSO,
        Set single sign-on (SSO) for the session. When the user accesses a server, the user's logon credentials are passed to the server for authentication.
        Acceptable values: "ON","OFF", default to 'ON"
    .Parameter IcaProxy
        Enable ICA proxy to configure secure Internet access to servers running Citrix XenApp or XenDesktop by using Citrix Receiver instead of the Access Gateway Plug-in.
    .Parameter NtDomain
        Single sign-on domain to use for single sign-on to applications in the internal network. 
        This setting can be overwritten by the domain that users specify at the time of logon or by the domain that the authentication server returns.
    .Parameter ClientlessVpnMode
        Enable clientless access for web, XenApp or XenDesktop, and FileShare resources without installing the Access Gateway Plug-in. 
        Available settings function as follows: * ON - Allow only clientless access. * OFF - Allow clientless access after users log on with the Access Gateway Plug-in. * DISABLED - Do not allow clientless access.
    .Parameter ClientChoices
        Provide users with multiple logon options. With client choices, users have the option of logging on by using the Access Gateway Plug-in for Windows, Access Gateway Plug-in for Java, the Web Interface, or clientless access from one location.
        Depending on how Access Gateway is configured, users are presented with up to three icons for logon choices. The most common are the Access Gateway Plug-in for Windows, Web Interface, and clientless access.
    .Parameter StoreFrontUrl,
        Web address for StoreFront to be used in this session for enumeration of resources from XenApp or XenDesktop.
    .Parameter WIHome
        Web address of the Web Interface server, such as http:///Citrix/XenApp, or Receiver for Web, which enumerates the virtualized resources, such as XenApp, XenDesktop, and cloud applications.
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-SessionAction -NSIP 10.108.151.1 -SessionActionName AC_OS_10.108.151.1_S_ -TransparentInterception OFF -SplitTunnel OFF `
        -DefaultAuthorizationAction ALLOW -SSO ON -IcaProxy ON -NtDomain xd.local -ClientlessVpnMode OFF -ClientChoices OFF `
        -WIHome "http://10.8.115.243/Citrix/StoreWeb" -StoreFrontUrl "http://10.8.115.243" -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $SessionActionName,
    [Parameter(Mandatory=$false)][string][ValidateSet("ON","OFF")] $TransparentInterception="OFF",
    [Parameter(Mandatory=$false)][string][ValidateSet("ON","OFF","REVERSE")] $SplitTunnel="OFF",
    [Parameter(Mandatory=$false)][string][ValidateSet("ALLOW","DENY")] $DefaultAuthorizationAction="DENY",
    [Parameter(Mandatory=$false)][string][ValidateSet("ON","OFF")] $SSO="ON",
    [Parameter(Mandatory=$false)][string][ValidateSet("ON","OFF")] $IcaProxy="OFF",
    [Parameter(Mandatory=$false)][string] $NtDomain,
    [Parameter(Mandatory=$false)][string][ValidateSet("ON","OFF","DISABLED")] $ClientlessVpnMode="OFF",
    [Parameter(Mandatory=$false)][string][ValidateSet("ON","OFF")] $ClientChoices="OFF",
    [Parameter(Mandatory=$false)][string] $StoreFrontUrl,
    [Parameter(Mandatory=$false)][string] $WIHome="$StoreFrontUrl/Citrix/StoreWeb",
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload =  @{name=$SessionActionName;transparentinterception=$TransparentInterception;splittunnel=$SplitTunnel;defaultauthorizationaction=$DefaultAuthorizationAction;SSO=$SSO;icaproxy=$IcaProxy;wihome=$WIHome;clientchoices=$ClientChoices;ntdomain=$NtDomain;clientlessvpnmode=$ClientlessVpnMode;}
    if(-not [string]::IsNullOrEmpty($StoreFrontUrl)){
        $payload.storefronturl=$StoreFrontUrl
    }
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType vpnsessionaction -WebSession $WebSession -Payload $payload -Action add 

}

function Add-SessionPolicy {
    <#
    .SYNOPSIS
        Add VPN Session policy resources
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Add VPN Session policy resources
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter SessionActionName
        Action to be applied by the new session policy if the rule criteria are met.
    .Parameter SessionPolicyName
        Name for the new session policy that is applied after the user logs on to Access Gateway.
    .Parameter SessionRuleExpression
        Expression, or name of a named expression, specifying the traffic that matches the policy.
        Can be written in either default or classic syntax. 
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        Add-SessionPolicy -NSIP $NSIP -SessionActionName AC_OS_10.108.151.1_S_ -SessionPolicyName PL_OS_10.108.151.1 `
        -SessionRuleExpression "REQ.HTTP.HEADER User-Agent CONTAINS CitrixReceiver || REQ.HTTP.HEADER Referer NOTEXISTS" -WebSession $Session

    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $SessionActionName,
    [Parameter(Mandatory=$true)][string] $SessionPolicyName,
    [Parameter(Mandatory=$true)][string] $SessionRuleExpression,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{name=$SessionPolicyName;action=$SessionActionName;rule=$SessionRuleExpression}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod post -ResourceType vpnsessionpolicy -WebSession $WebSession -Payload $payload -Action add 

}

function New-VServeSessionPolicyBinding {
    <#
    .SYNOPSIS
        Bind vpn session policy to vpnvserver.
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Bind vpn session policy to vpnvserver.
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter VServerName
        Name of the virtual server.
    .Parameter SessionPolicyName
        The name of the policy, if any, bound to the vpn vserver.
    .Parameter Priority
        The priority, if any, of the vpn vserver policy. 
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        New-VServeSessionPolicyBinding -NSIP 10.108.151.1 -VServerName myvs -SessionPolicyName PL_OS_10.108.151.3 -Priority 100 -WebSession $Session
        New-VServeSessionPolicyBinding -NSIP 10.108.151.1 -VServerName myvs -SessionPolicyName PL_WB_10.108.151.3 -Priority 100 -WebSession $Session

    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $VServerName,
    [Parameter(Mandatory=$true)][string] $SessionPolicyName,
    [Parameter(Mandatory=$true)][string] $Priority,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{name=$VServerName;policy=$SessionPolicyName;priority=$Priority}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod put -ResourceType vpnvserver_vpnsessionpolicy_binding -WebSession $WebSession -Payload $payload -Action add 

}

function New-VServerSTAServerBinding {
    <#
    .SYNOPSIS
        Bind staserver to vpnvserver.
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Bind staserver to vpnvserver.
    .Parameter NSIP
        NetScaler Management IPAddress
    .Parameter VServerName
        Name of the virtual server.
    .Parameter STAServer
        Configured Secure Ticketing Authority (STA) server.
    .Parameter WebSession
        An existing Web Request Session object, usually returned from an earlier invoke-restmethod function
    .EXAMPLE
        New-VServerSTAServerBinding -NSIP 10.108.151.1 -VServerName myvs -STAServer "http://10.108.156.7" -WebSession $Session
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string] $NSIP,
    [Parameter(Mandatory=$true)][string] $VServerName,
    [Parameter(Mandatory=$true)][string] $STAServer,
    [Parameter(Mandatory=$true)] $WebSession
    )
    $payload = @{name=$VServerName;staserver=$STAServer}
    $Job = Invoke-NitroAPI -NSIP $NSIP -OperationMethod put -ResourceType vpnvserver_staserver_binding -WebSession $WebSession -Payload $payload -Action add 

}

function Set-Protocol{
    <#
    .SYNOPSIS
        Set $Script:URLProtocol, this will be used for all subsequent invocation of NITRO APIs
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Set $Script:URLProtocol
    .Parameter Protocol
        Protocol, acceptable values are "http" and "https"
    .EXAMPLE
        Set-Protocol -Protocol https
    #>
    [CmdletBinding()]
    param(
    [Parameter(Mandatory=$true)][string][ValidateSet("http","https")] $Protocol
    )
    $Script:URLProtocol = $Protocol
}

function Get-Protocol{
    <#
    .SYNOPSIS
        Get the value of $Script:URLProtocol
        Copyright (c) Citrix Systems, Inc. All Rights Reserved.
    .DESCRIPTION
        Set $Script:URLProtocol
    .EXAMPLE
        $protocol  = Get-Protocol
    #>
    [CmdletBinding()]
    param()
    return $Script:URLProtocol 
}

function Get-ScriptDirectory
{
    $Invocation = (Get-Variable MyInvocation -Scope 1).Value
    Split-Path $Invocation.MyCommand.Path
}

$PlinkPath = ((Get-ScriptDirectory) + "\plink.exe")

Function Invoke-NetscalerSSH 
{
    Param($Hostname, $Credentials, $Commands)
    
	$username = $Credentials.Username
    $password = $Credentials.GetNetworkCredential().password
    
	Set-Protocol "HTTP"

    $session = Connect-NSVPX -NSIP $Hostname -NSUserName $username -NSPassword $password -ErrorAction Stop
	Disconnect-NSVPX -NSIP $Hostname -WebSession $session
    
    $linkPath = "C:\Program Files\WindowsPowerShell\Modules\CitrixNetScaler\DSCResources\plink.exe"
    $cmd = "echo ping"
    $Target = $Username + '@' + $Hostname
    try{
      $msg = Invoke-Expression 'echo Y | &$PlinkPath -ssh $Target -l $username -pw $password exit' -ErrorAction SilentlyContinue 2>$null
      $msg1 = &$PlinkPath -ssh $Target -l $username -pw $password shell $cmd
    } catch {}


}

Function Invoke-NetscalerSSHRaw
{
    Param($Hostname, $Credentials,  $Commands)
    
    $username = $Credentials.Username
    $Password = $Credentials.GetNetworkCredential().password

	Set-Protocol "HTTP"
    $session = Connect-NSVPX -NSIP $Hostname -NSUserName $username -NSPassword $Password -ErrorAction Stop
	Disconnect-NSVPX -NSIP $Hostname -WebSession $session

    $Target = $Username + '@' + $Hostname
    $plinkoptions = "-ssh $Target -pw $Password"
    
    $cmd = "echo ping"
       
    
    try {
        $msg = Invoke-Expression 'echo Y | &$PlinkPath -ssh $Target -l $username -pw $password exit' -ErrorAction SilentlyContinue 2>$null
        $msg1 =Invoke-Expression '&$PlinkPath -ssh $Target -l $username -pw $Password $cmd' -ErrorAction SilentlyContinue 2>$null
    } catch { }

    #format plist command
    
    $msgs = & $PlinkPath -ssh $Target -l $username -pw $Password $Commands
    $msgs | ?{ -not ($_ -eq " Done") }
}

$PscpPath = ((Get-ScriptDirectory) + "\pscp.exe")

Function Invoke-NetscalerPSCP 
{
    Param($Hostname, $Credentials, $Local, $Target)

    $Username = $Credentials.Username
    $Password = $Credentials.GetNetworkCredential().password
    
	Set-Protocol "HTTP"
    $session = Connect-NSVPX -NSIP $Hostname -NSUserName $Username -NSPassword $Password -ErrorAction Stop
	Disconnect-NSVPX -NSIP $Hostname -WebSession $session
    
    $target1 = $Username + '@'+ $Hostname+ ':'+  $Target

    $msg = echo Y | &$PscpPath -pw $Password $Local $target1

    ##$command = [string]::Format('echo y | & "{0}" -pw {3} "{1}" "{2}"', $PscpPath, $Local, "$($Username)@$($Hostname):$($Target)", $Password)

   ## Invoke-Expression $command -ErrorAction SilentlyContinue
}