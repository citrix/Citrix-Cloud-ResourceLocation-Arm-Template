#
# DomainController.ps1
#
configuration DomainController 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 

    Import-DscResource -ModuleName xActiveDirectory,xDisk, xNetworking, cDisk, xAdcsDeployment,CitrixMarketplace,xSmbShare,xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

	$Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
        } 

        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
        }
        
		Script DNSDiagnostics
		{
      	    SetScript =  { 
				Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics" 
            }
            GetScript =  { @{} }
            TestScript = { $false}
			DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
            DependsOn = "[Script]DNSDiagnostics"
        }  

        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
            DependsOn = "[WindowsFeature]ADDSInstall"
        }      

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
             DependsOn = "[WindowsFeature]ADDSTools"
        }

        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitforDisk]Disk2"
        }

        xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = "[cDiskNoRestart]ADDataDisk" 
        } 

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn = "[xADDomain]FirstDS" 
        }

        WindowsFeature ADCS-Cert-Authority 
        { 
            Ensure = 'Present' 
            Name = 'ADCS-Cert-Authority'
            DependsOn = "[xDnsServerAddress]DnsServerAddress"
        } 

        xADCSCertificationAuthority ADCS 
        { 
            Ensure = 'Present' 
            Credential = $DomainCreds 
            CAType = 'EnterpriseRootCA' 
            CACommonName = 'DomainCA'
			HashAlgorithmName='SHA256'
            DependsOn = '[WindowsFeature]ADCS-Cert-Authority'               
        } 

        xPendingReboot Pretest
        { 
            Name = "BeforeADCSInstall"
            DependsOn = '[xADCSCertificationAuthority]ADCS'
        }

        WindowsFeature ADCS-Web-Enrollment 
        { 
            Ensure = 'Present' 
            Name = 'ADCS-Web-Enrollment' 
            DependsOn = '[WindowsFeature]ADCS-Cert-Authority' 
        } 

        xADCSWebEnrollment CertSrv 
        { 
            Ensure = 'Present' 
            Name = 'CertSrv' 
            Credential = $DomainCreds            
            DependsOn = '[WindowsFeature]ADCS-Web-Enrollment','[xADCSCertificationAuthority]ADCS' 
        }  

		xPendingReboot Reboot
        { 
            Name = "RebootServer"
            DependsOn = '[xADCSWebEnrollment]CertSrv'
        }
 
    }
}