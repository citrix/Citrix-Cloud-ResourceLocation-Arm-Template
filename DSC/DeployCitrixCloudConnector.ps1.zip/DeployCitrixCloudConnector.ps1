#
# DeployCitrixCloudConnector.ps1
#
configuration DeployCitrixCloudConnector
{
    param
    (
		[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
		
		[Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$DomainControllerIp,
		
		[Parameter(Mandatory)]
        [String]$NetScalerIP,
	    
	    # StoreFront
        [Parameter(Mandatory)]
        [String]$StoreFront,

        [Parameter(Mandatory)]
        [String]$VirtualServerName,

        [Parameter(Mandatory)]
        [Int]$VirtualServerPort,

        [Parameter(Mandatory)]
        [Int]$ForwardServerPort,

        [Parameter(Mandatory)]
        [String]$StoreFrontGatewayName,

        [Parameter(Mandatory)]
        [String]$EmailAddress,

        [Parameter(Mandatory)]
	    [ValidateSet("ACME", "Enterprise")]
        [String]$Authority,

        [Parameter(Mandatory)]
        [String]$ACMEServer,

        [Parameter(Mandatory)]
        [String]$GatewayFQDN,

        [Parameter(Mandatory)]
        [String]$DeploymentFQDN,

		[Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$CertificatePassword,
		
        [Parameter(Mandatory)]
        [String]$CustomerId,
		
        [Parameter(Mandatory)]
        [String]$ClientId,
		
        [Parameter(Mandatory)]
        [String]$ClientSecret,
		
        [Parameter(Mandatory)]
        [String]$customerResourceLocationsId,
						
		[String]$CustomCloudConnectorScriptUri,
		
		[string]$CustomCloudConnectorScriptArgs
)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
	Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xCertificate, xWebAdministration, CitrixNetscaler,ACMEPowerShell, ACMECertificate, xSmbShare, xNetworking, CitrixMarketplace
	Import-DSCResource -Module xSystemSecurity -Name xIEEsc 
    Import-DSCResource -ModuleName CloudConnector -Name CloudConnector  -ModuleVersion 1.0

	
	[System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
	$certPassword = $CertificatePassword.GetNetworkCredential().Password
		
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    $DscScriptPath = $pwd

    $iisPath = "C:\\inetpub\\wwwroot"
    $vaultPath = "C:\Vault"
	$keyFile = "$vaultPath\key.pem"
	$pairFile = "$vaultPath\pair.pem"
	$certFile = "$vaultPath\cert.pem"

	Node localhost
	{		               
        
		LocalConfigurationManager 
		{ 
			RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
		} 
				
		WindowsFeature ADPowershell
		{
			Name = "RSAT-AD-PowerShell"
			Ensure = "Present"
		} 
		
         WindowsFeature InstallWebServer
        {
            Name = "Web-Server"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]ADPowershell"
        }
        
        WindowsFeature InstallWebAsp
        {
            Name = "Web-Asp-Net45"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]InstallWebServer"
        }

        WindowsFeature InstallWebConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]InstallWebAsp"
        }

		xDnsServerAddress DnsServerAddress
		{
			Address        = $DomainControllerIp
			InterfaceAlias = $InterfaceAlias
			AddressFamily  = 'IPv4'
		}

		 xWaitForADDomain WaitForDomain 
		{ 
			DomainName = $DomainName 
			DomainUserCredential= $Admincreds
			RetryCount = $RetryCount 
			RetryIntervalSec = $RetryIntervalSec
			DependsOn = "[xDnsServerAddress]DnsServerAddress" 
		}

		xComputer DomainJoin
		{
			Name = $env:COMPUTERNAME
			DomainName = $DomainName
			Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]WaitForDomain" 
		}
				
	    Citrix_MarketplaceDomain Domain
        { 
            DeploymentFQDN = $DeploymentFQDN
            GatewayFQDN = $GatewayFQDN
			EmailAddress = $EmailAddress
			IisRoot = $iisPath
        }

        Script EnsureCA
        { 
			GetScript = { @{} }
			SetScript = { gpupdate /force }
			TestScript = {
                if(dir Cert:\LocalMachine\CA | ?{$_.Subject -match "DomainCA" })
                {
                    Write-Verbose "The root CA certificate Already exists"
                    return $true
                }
                else
                {
                   Write-Verbose "The root CA certificate does not exist"
                   return $false
                }
                        
            }
            DependsOn = "[xComputer]DomainJoin"
               
        }

        xCertReq SSLCert
        {
            CARootName = 'DomainCA'
            CAServerFQDN = $DomainController
            Subject = $StoreFront
            AutoRenew = $true
            Credential = $DomainCreds
            DependsOn = "[Script]EnsureCA"
        }


        xWebSite DefaultWebSite {
            Name = 'Default Web Site';
            PhysicalPath = 'C:\inetpub\wwwroot';
            BindingInfo = @(
                MSFT_xWebBindingInformation  { Protocol = 'HTTPS'; Port = 443; CertificateThumbprint = $DeliveryController; CertificateStoreName = 'My'; }
                MSFT_xWebBindingInformation  { Protocol = 'HTTP'; Port = 80; }
            )
            DependsOn = '[xCertReq]SSLCert';
        }

		if($Authority -match "ACME")
		{
			$certName = "certificate.pem"

			ACME_CertificateRequest CertRequest
			{ 
				ACMEServer = $AcmeServer
				CommonName = $GatewayFQDN
				EmailAddress = $EmailAddress
				CertificatePassword = $CertificatePassword
				VaultPath = $vaultPath
				CertPath = $certFile
				KeyPath = $keyFile
				PairPath = $pairFile
				IISPath = $iisPath
			}
			
			Citrix_NetscalerLocalFile Certificate 
			{
				Filename = "/nsconfig/ssl/$certName"
				NetScalerIP = $NetScalerIP
				NetscalerCredential = $Admincreds
				LocalPath = $pairFile
				Ensure = "Present"
				DependsOn = "[ACME_CertificateRequest]CertRequest"
			}
		}
		else
		{
			$certName = "certificate.pfx"
			$certPath = "$vaultPath\$certName"

			xCertReq SelfSigned
			{
				CARootName = 'DomainCA'
				CAServerFQDN = $DomainController
				Subject = $GatewayFQDN
				AutoRenew = $true
				Credential = $DomainCreds
				DependsOn = "[Citrix_MarketplaceDomain]Domain" 
			}

			Script ExportSelfSigned
			{
				GetScript = { @{ } }
				SetScript = { 
					$cert = dir Cert:\LocalMachine\My | ?{$_.Subject -match $using:GatewayFQDN }
					New-Item $using:vaultPath -Type Directory
					Export-PfxCertificate -Cert $cert -NoProperties -ChainOption BuildChain -Password (ConvertTo-SecureString -AsPlainText -Force $using:certPassword) -FilePath $using:certPath
				}
				TestScript = { Test-Path $using:certPath }
				DependsOn = "[xCertReq]SelfSigned"
			}

			Citrix_NetscalerLocalFile Certificate 
			{
				Filename = "/nsconfig/ssl/$certName"
				NetScalerIP = $NetScalerIP
				NetscalerCredential = $Admincreds
				LocalPath = $certPath
				Ensure = "Present"
				DependsOn = "[Script]ExportSelfSigned"
			}
		}
		
		Citrix_NetscalerConfigureXD NSConfig 
		{
			NetScalerIP = $NetScalerIP
			NetscalerCredential = $Admincreds
			DomainCredential = $Admincreds
			CertificatePassword = $CertificatePassword
			CertificateFile = $certName
			DomainName = $DomainName
			DomainController= $DomainControllerIp
			StorefrontServer = $StoreFront
			DeliveryController = $StoreFront
			VirtualServerName = $VirtualServerName
			VirtualServerPort = $VirtualServerPort
			ForwardServerPort = $ForwardServerPort
			DependsOn = "[Citrix_NetscalerLocalFile]Certificate"
		}
       
        
		if($ACMEServer -match "staging")
		{
			Script StagingCert
	        {
				SetScript = {
					$encodedCer = "MIIDETCCAfmgAwIBAgIJAJzxkS6o1QkIMA0GCSqGSIb3DQEBCwUAMB8xHTAbBgNVBAMMFGhhcHB5IGhhY2tlciBmYWtlIENBMB4XDTE1MDQwNzIzNTAzOFoXDTI1MDQwNDIzNTAzOFowHzEdMBsGA1UEAwwUaGFwcHkgaGFja2VyIGZha2UgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDCCkd5mgXFErJ3F2M0E9dw+Ta/md5i8TDId01HberAApqmydG7UZYF3zLTSzNjlNSOmtybvrSGUnZ9r9tSQcL8VM6WUOM8tnIpiIjEA2QkBycMwvRmZ/B2ltPdYs/R9BqNwO1g18GDZrHSzUYtNKNeFI6Glamj7GK2Vr0SmiEamlNIR5ktAFsEErzf/d4jCF7sosMsJpMCm1p58QkP4LHLShVLXDa8BMfVoI+ipYcA08iNUFkgW8VWDclIDxcysa0psDDtMjX3+4aPkE/cefmP+1xOfUuDHOGV8XFynsP4EpTfVOZr0/g9gYQ7ZArqXX7GTQkFqduwPm/w5qxSPTarAgMBAAGjUDBOMB0GA1UdDgQWBBT7eE8S+WAVgyyfF380GbMuNupBiTAfBgNVHSMEGDAWgBT7eE8S+WAVgyyfF380GbMuNupBiTAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQAd9Da+Zv+TjMv7NTAmliqnWHY6d3UxEZN3hFEJ58IQVHbBZVZdW7zhRktBvR05Kweac0HJeK91TKmzvXl21IXLvh0gcNLU/uweD3no/snfdB4OoFompljThmglzBqiqWoKBJQrLCA8w5UB+ReomRYd/EYXF/6TAfzm6hr//Xt5mPiUHPdvYt75lMAovRxLSbF8TSQ6b7BYxISWjPgFASNNqJNHEItWsmQMtAjjwzb9cs01XH9pChVAWn9LoeMKa+SlHSYrWG93+EcrIH/dGU76uNOiaDzBSKvaehG53h25MHuO1anNICJvZovWrFo4Uv1EnkKJm3vJFe50eJGhEKlx"
					$binaryCer = [Convert]::FromBase64String($encodedCer)

					$pfx = new-object System.Security.Cryptography.X509Certificates.X509Certificate2
					$pfx.import($binaryCer)

					$store = new-object System.Security.Cryptography.X509Certificates.X509Store(
						[System.Security.Cryptography.X509Certificates.StoreName]::Root,
						"localmachine"
					)

					$store.open("MaxAllowed")
					$store.add($pfx)
					$store.Close()
				}
				TestScript = { 
					Test-Path "Cert:\localmachine\Root\5F5968E72FFD87450DD50E5EE96A1B793F110D46"
				}
				GetScript = { 
					return @{ Key = "Test-Path Cert:\localmachine\Root\5F5968E72FFD87450DD50E5EE96A1B793F110D46" }
				}          
			}
		}
		
		xIEEsc DisableIEEsc 
        { 
            IsEnabled = $false 
            UserRole = "Users" 
        } 	    
        
        CloudConnector InstallCloudConnector
        {
            CustomerId = $CustomerId
            APIClientID = $ClientId
            APIClientSecret = $ClientSecret
            ResourceLocation = $customerResourceLocationsId
            ConnectorDowloadPath = $DscScriptPath				
            DependsOn = "[xComputer]DomainJoin"
        }
		
		
		Script CustomScript
		{
			SetScript = {
				$downloadPath = (Join-Path -Path $DscScriptPath -ChildPath "CustomScript.ps1")
				try{
					Invoke-WebRequest -Uri $CustomCloudConnectorScriptUri -OutFile $downloadPath
				}
				catch [System.Net.WebException] {
					Throw "Unable to download CustomScript $_"
				}
				if (Test-Path $downloadPath) {
					Write-Host "CustomScript downloaded succesfully from $downloadsUri to $downloadPath"
					Start-Process $downloadPath $CustomCloudConnectorScriptArgs -Wait
				}
			
			}
			TestScript = { 
				[string]::IsNullOrWhitespace($CustomCloudConnectorScriptUri)
			}
			GetScript = { 
				@{ }
			}     
		DependsOn = "[CloudConnector]InstallCloudConnector"			
		}

		
	}	
} 
