#
# VDA.ps1
#
configuration VDI
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$DomainControllerIp,

        [Parameter(Mandatory)]
        [String]$DeliveryController        
    ) 

    Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
    
    Import-DscResource -ModuleName CitrixXenDesktopAutomation, CitrixMarketplace, cChoco, xNetworking,  xActiveDirectory, xComputerManagement

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    
	$Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

	$currentVdiInstallerDir = (join-path -Path $PSScriptRoot -ChildPath "VDISetup")
	
    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
        } 

		WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 
		
		Registry ListOfDDC
        {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\Software\Citrix\VirtualDesktopAgent"
            ValueName = "ListOfDDCs"
            ValueData = $DeliveryController
            DependsOn = "[WindowsFeature]ADPowershell" 
        }
		
	    xDnsServerAddress DnsServerAddress
        {
            Address        = $DomainControllerIp
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }

		
		 xWaitForADDomain WaitForDomain 
		{ 
			DomainName = $DomainName 
			DomainUserCredential= $Admincreds
			RetryCount = $RetryCount 
			RetryIntervalSec = $RetryIntervalSec
			DependsOn = "[xDnsServerAddress]DnsServerAddress" 
		}

		xComputer DomainJoin
		{
			Name = $env:COMPUTERNAME
			DomainName = $DomainName
			Credential = $DomainCreds
			DependsOn = "[xWaitForADDomain]WaitForDomain" 
		}
				
		Script InstallXDPoshSdk            
        {            
          
            GetScript = { @{} }      
                     
            TestScript = {            
                return ((Test-Path $using:currentVdiInstallerDir) -eq $false)

            }            
            
            SetScript = {                            
                Copy-Item $using:currentVdiInstallerDir "c:\"  -Recurse -Force
                Start-Process "C:\VDISetup\VDAWorkstationSetup_7.9.exe" "-silent" "/CONTROLLERS:$DeliveryController" -Wait

            }            
            DependsOn ="[xComputer]DomainJoin"
        }   
    }
} 
