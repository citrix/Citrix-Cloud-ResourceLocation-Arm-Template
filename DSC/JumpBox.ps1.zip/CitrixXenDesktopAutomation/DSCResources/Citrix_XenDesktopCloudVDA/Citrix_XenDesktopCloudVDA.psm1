﻿function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$XenDesktopController,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CatalogName,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryGroupName,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String[]]
		$Users,

		[System.String]
		$PublishedApplications,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StoreFrontUrl

	)

    process
    {
	    return @{
		    XenDesktopController = $XenDesktopController
		    CatalogName = $CatalogName
		    DeliveryGroupName = $DeliveryGroupName
            Users = $Users
            PublishedApplications = $PublishedApplications
            StoreFrontUrl = $StoreFrontUrl
	    }
    }
}


function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$XenDesktopController,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CatalogName,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryGroupName,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String[]]
		$Users,

		[System.String]
		$PublishedApplications,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StoreFrontUrl
	)

    process
    {
        # This resource attempts to be resilient on reapplication, configuring only that which has changed

        asnp citri*
	    
	    
        try
        {
            $sid = Get-Sid
        }
        catch
        {
            Write-Verbose "Exhausted retries obtaining SID, reboot as a last ditch effort."
            $global:DSCMachineStatus = 1
            return
        }

	    # Catalog creation
	
        $catalog = (get-brokercatalog  | ?{$_.Name -eq $CatalogName})

        if($catalog -eq $null)
        {
		    try
		    {
			    Write-Verbose "Creating catalog $CatalogName"
			
			    $catalog = New-BrokerCatalog  -AllocationType Random -IsRemotePC $False -MachinesArePhysical $True -MinimumFunctionalLevel L7_9 `
                                              -Name $CatalogName -PersistUserChanges OnLocal -ProvisioningType Manual `
                                              -Scope @() -SessionSupport MultiSession
		    }
		    catch
		    {
			    Write-Verbose "Failed to create catalog $CatalogName. Possibly already exists."
		
			    $catalog = (get-brokercatalog  | ?{$_.Name -eq $CatalogName})
		    }
        }
    
	    # Delivery group creation

        $group = (get-brokerdesktopgroup  | ?{$_.Name -eq $DeliveryGroupName})
    
        if($group -eq $null)
        {
		    try
		    {
			    Write-Verbose "Creating delivery group $DeliveryGroupName"

			    $group = New-BrokerDesktopGroup  -ColorDepth TwentyFourBit `
                                                -DeliveryType AppsOnly -Description $DeliveryGroupName -DesktopKind Shared `
                                                -InMaintenanceMode $False -IsRemotePC $False -MinimumFunctionalLevel L7_9 `
                                                -Name $DeliveryGroupName -OffPeakBufferSizePercent 10 -PeakBufferSizePercent 10 `
                                                -PublishedName $DeliveryGroupName -Scope @() -SecureIcaRequired $False `
                                                -SessionSupport MultiSession -TimeZone "UTC"
		    }
		    catch
		    {
			    Write-Verbose "Failed to create delivery group $DeliveryGroupName. Possibly already exists."
			
			    $group = (get-brokerdesktopgroup  | ?{$_.Name -eq $DeliveryGroupName})
		    }
        }

	    # Machine addition
	
	    $machine = New-BrokerMachine  -CatalogUid $catalog.Uid -MachineName $sid
	
	    Add-BrokerMachinesToDesktopGroup  -Catalog $CatalogName -Count 1 `
                                          -DesktopGroup $DeliveryGroupName
	
	    # Entitlement
	
	    $appEntitlementName = "$($DeliveryGroupName)_App"
	    $deskEntitlementName = "$($DeliveryGroupName)_Desk"
	
	    if((Test-BrokerEntitlementPolicyRuleNameAvailable -Name $deskEntitlementName).Available) 
	    {
		    try
		    {
			    Write-Verbose "Creating desktop entitlement '$deskEntitlementName'"
			
			    New-BrokerEntitlementPolicyRule  -DesktopGroupUid $group.Uid -Enabled $True `
                                                 -IncludedUserFilterEnabled $False -Name $deskEntitlementName
		    }
		    catch
		    {
			    Write-Verbose "Failed to create desktop entitlement '$deskEntitlementName'. Possibly already exists."
		    }
	    }

	    if((Test-BrokerAppEntitlementPolicyRuleNameAvailable -Name $appEntitlementName).Available) 
	    {
		    try
		    {
			    Write-Verbose "Creating app entitlement '$appEntitlementName'"
			
			    New-BrokerAppEntitlementPolicyRule -DesktopGroupUid $group.Uid -Enabled $True `
                                                   -IncludedUserFilterEnabled $False -Name $appEntitlementName
		    }
		    catch
		    {
			    Write-Verbose "Failed to create app entitlement '$appEntitlementName'. Possibly already exists."
		    }
	    }

	    # Access policy creation
	
        $brokerUsers = ($users | %{New-BrokerUser  -Name $_ }) | %{ $_.name }
    
        $directName = "$($DeliveryGroupName)_Direct"
        $agName = "$($DeliveryGroupName)_AG"

        if((Test-BrokerAccessPolicyRuleNameAvailable  -Name $directName ).Available)
        {
		    try
		    {
			    Write-Verbose "Creating access policy $directName."
			
			    New-BrokerAccessPolicyRule -AllowedConnections NotViaAG `
                                           -AllowedProtocols @("HDX","RDP") -AllowedUsers Filtered -AllowRestart $True `
                                           -DesktopGroupUid $group.Uid -Enabled $True -IncludedSmartAccessFilterEnabled $True `
                                           -IncludedUserFilterEnabled $True -IncludedUsers @($brokerUsers) -Name $directName
		    } 
		    catch 
		    {
			    Write-Verbose "Access policy $directName already created."
		    }
        }

        if((Test-BrokerAccessPolicyRuleNameAvailable  -Name $agName ).Available)
        {
		    try
		    {
			    Write-Verbose "Creating access policy $agName."
			
			    New-BrokerAccessPolicyRule -AllowedConnections ViaAG `
                                           -AllowedProtocols @("HDX","RDP") -AllowedUsers Filtered -AllowRestart $True `
                                           -DesktopGroupUid $group.Uid -Enabled $True -IncludedSmartAccessFilterEnabled $True `
                                           -IncludedSmartAccessTags @() -IncludedUserFilterEnabled $True `
                                           -IncludedUsers @($brokerUsers) -Name $agName
		    } 
		    catch 
		    {
			    Write-Verbose "Access policy $agName already created."
		    }
        }

        DO
        {
            Start-Sleep -s 30            
        }While(((Get-BrokerMachine -SID $sid -Property RegistrationState).RegistrationState -ne 'Registered'))

	    $computerName=(Get-BrokerMachine -SID $sid -Property MachineName).MachineName
    
	    # Application publishing

        foreach($application in ($PublishedApplications | ConvertFrom-Json))
        {
		    $name = $application.name
            $category = $application.category
		    $path = $application.path
            $icon = $application.icon
		    $arguments = $application.arguments

            Write-Verbose $name
            if((Get-PathType -path $path) -eq "Shortcut")
            {
                $brokerShortcut = Get-BrokerMachineStartMenuShortcuts -MachineName $computerName | ?{ $_.ShortcutPath -eq $path }

			    $arguments = (@($brokerShortcut.CommandLineArguments, $arguments) | ?{ $_ }) -join " "
			    $path = $brokerShortcut.CommandLineExecutable
            }

            if((Get-PathType -path $icon) -eq "Shortcut")
            {
			    $brokerShortcutIcon = Get-BrokerMachineStartMenuShortcutIcon -MachineName $computerName -Path $icon
            }
            else
            {
				try {
			    	$brokerShortcutIcon = (Get-CtxIcon -FileName $icon | Select-Object -First 1).EncodedIconData
				}
				catch
				{
					Write-Verbose "Exception reading icon file"
					Write-Verbose $_
					$brokerShortcutIcon=$null
				}
            }

            $application = Get-BrokerApplication -DesktopGroupUid $group.Uid | ?{$_.BrowserName -eq $name }

            if($application -eq $null -and $brokerShortcutIcon -ne $null)
            {
			    try
			    {
				    Write-Verbose "Publishing application for path ($path)"
				
				    $brokerIcon = New-BrokerIcon -EncodedIconData $brokerShortcutIcon
				    $brokerApplication = New-BrokerApplication  -ApplicationType HostedOnDesktop `
                                                                -CommandLineArguments $arguments -CommandLineExecutable $path `
                                                                -CpuPriorityLevel "Normal" -DesktopGroup $group.Uid -Enabled $True `
                                                                -IconUid $brokerIcon.Uid -Name $name -Priority 0 -PublishedName $name `
                                                                -SecureCmdLineArgumentsEnabled $True -ShortcutAddedToDesktop $True `
                                                                -ShortcutAddedToStartMenu $True -UserFilterEnabled $False -Visible $True `
                                                                -WaitForPrinterCreation $False -ClientFolder $category
			    }
			    catch
			    {
				    Write-Verbose "Failed to publish application for path ($path). Possibly already exists."
					Write-Verbose("Exception ($_)")
			    }
            }
        }
    }
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$XenDesktopController,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CatalogName,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryGroupName,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String[]]
		$Users,

		[System.String]
		$PublishedApplications,

		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StoreFrontUrl
	)
	
    process
    {
        # Naively assumes that if the machine has joined the catalog, that there is no need set the resource
        # Much better approach would be to test the individual settings
        $VerbosePreference = "Continue"
	    asnp citri*
        
        

        Set-XDCredentials -CustomerId "kirarsdev" -APIKey "79262146-4f39-4b19-853e-f3b5cacafca5" -SecretKey "_aS8rAcUyUCB6qa0MxKF3g==" -ProfileType CloudApi -StoreAs "default" 
        try
        {
	        $sid = Get-Sid
        } 
        catch
        {
            return $false
        }
	    $machine = Get-BrokerMachine | ?{ $_.SID -eq $sid }

	    return ($machine -ne $null)
    }
}

<#
    .SYNOPSIS
        Given a path, returns the type of file in a more friendly way
    .NOTES
        Examines the path to determin if file is a shortcut or something else
    .PARAMETER path
        Path to examine
#>
function Get-PathType
{
    param($path)

    if($path -match "\.lnk$")
    {
        return "Shortcut"
    }
    else
    {
        return "Executable"
    }
}

<#
    .SYNOPSIS
        Returns the current computer's SID
    .NOTES
        This can fail if domain communication is off, so we retry a number of times
#>
function Get-Sid
{
    for($i = 0; $i -lt 30; $i++)
    {
        try
        {
    	    $sid = (Get-ADComputer -Filter "name -eq 'XA-VDA'" -Properties sid).SID.Value
            return $sid
        }
        catch
        {
            Write-Verbose "Failed to obtain SID, retrying..."
        }
    }

    throw "Timed out trying to obtain SID"
}

Export-ModuleMember -Function *-TargetResource

