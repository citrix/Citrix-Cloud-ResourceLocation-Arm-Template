#
# JumpBox.ps1
#
configuration JumpBox 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [Hashtable[]]$Shortcuts,

        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$DomainControllerIp,

        [Parameter(Mandatory)]
        [String]$DeliveryController,

        [Parameter(Mandatory)]
        [String]$DeploymentFQDN,

        [Parameter(Mandatory)]
        [String]$GatewayFQDN,

		[Parameter(Mandatory)]
        [String]$CustomerId,
		
        [Parameter(Mandatory)]
        [String]$clientId,
		
        [Parameter(Mandatory)]
        [String]$ClientSecret,
		
        [Parameter(Mandatory)]
        [String]$ResourceLocationId,
		
		[Parameter(Mandatory)]
        [String]$IsTestControlePlane,

		[Parameter(Mandatory)]
        [String]$CreateMasterImage,		
		
        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 

    Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1

    Import-DscResource -ModuleName CitrixXenDesktopAutomation, CitrixMarketplace, xSystemSecurity
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, cChoco, xNetworking
	
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    $desktopPath = "C:\Users\Public\Desktop"

    $currentPoshSdkDirectory = (join-path -Path $PSScriptRoot -ChildPath "CitrixPoshSdk")	
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)


    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 
       
        xDnsServerAddress DnsServerAddress
        {
            Address        = $DomainControllerIp
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }

		xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[xDnsServerAddress]DnsServerAddress" 
        }
	
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

        Script InstallXDPoshSdk            
        {            
            GetScript = {            
                Return $currentPoshSdkDirectory
            }            
                     
            TestScript = {            
                return ((Test-Path $using:currentPoshSdkDirectory) -eq $false)
            }            
            
            SetScript = {                            
                Copy-Item $using:currentPoshSdkDirectory "c:\"  -Recurse -Force
				if([System.Convert]::ToBoolean($IsTestControlePlane) -eq $true)
                {
					Start-Process "C:\CitrixPoshSdk\CitrixPoshSdk_TestControlePlane.exe" "-silent" -Wait
                }
				else
                {
					Start-Process "C:\CitrixPoshSdk\CitrixPoshSdk.exe" "-silent" -Wait
                }

            }            
            DependsOn ="[xComputer]DomainJoin"
        }   
        
        	
        Write-host "CreateMasterImage = " + $CreateMasterImage 
		Citrix_XenDesktopCloudVDI VDACatalog
		{
			XenDesktopController = $DeliveryController
			CatalogName = "Demo Desktop"
			DeliveryGroupName = "Demo Desktop"
			PSDscRunAsCredential = $DomainCreds
			Users = @($DomainCreds.UserName)
			CustomerId = $CustomerId
			APIKey = $clientId
			SecretKey = $ClientSecret
            CreateMasterImage = [System.Convert]::ToBoolean($CreateMasterImage)
			DependsOn = "[Script]InstallXDPoshSdk"			
		}
		
		foreach($shortcut in $Shortcuts) 
		{
			Citrix_MarketplaceShortcut $shortcut.name
			{
				Path = $shortcut.path
				Shortcut = $desktopPath + "\" + $shortcut.name + ".lnk"
				Arguments = $shortcut.arguments
			}
		}

		xIEEsc DisableIEEscUsers
        { 
            IsEnabled = $false 
            UserRole = "Users" 
        } 

        xIEEsc DisableIEEscAdministrators
        { 
            IsEnabled = $false 
            UserRole = "Administrators" 
        } 
    }
}